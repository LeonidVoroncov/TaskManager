﻿using System.Data;
using Dapper;
using TaskManager.Data.Authentications.Interfaces;
using TaskManager.Data.Authentications.Requests;
using TaskManager.Data.DataBase.Extensions;
using TaskManager.Data.DataBase.Interfaces;

namespace TaskManager.Data.Authentications.Implementations;

public class AuthenticationRepository(IDataBaseRepository repository) : IAuthenticationRepository
{
    public async Task<int> CreateUser(
        UserRegisterRequest request,
        CancellationToken cancellationToken
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_user_name", request.UserName)
            .AddParam("_first_name", request.FirstName)
            .AddParam("_last_name", request.LastName)
            .AddParam("_password", request.Password)
            .AddParam("_email", request.Email)
            .AddParam("_photo_name", request.PhotoName);
        
        var commandDefinition = new CommandDefinition(
            "public.set_user",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        var userId = (await repository.CallProcedure<int>(commandDefinition)).FirstOrDefault();
        
        return userId;
    }
}