﻿using TaskManager.Data.Authentications.Requests;

namespace TaskManager.Data.Authentications.Interfaces;

public interface IAuthenticationRepository
{
    Task<int> CreateUser(
        UserRegisterRequest request,
        CancellationToken cancellationToken
    );
}