﻿using System.Data;
using Dapper;
using TaskManager.Data.DataBase.Interfaces;
using TaskManager.Data.Statuses.Interfaces;
using TaskManager.Data.Statuses.Responses;

namespace TaskManager.Data.Statuses.Implementations;

public class StatusRepository(IDataBaseRepository repository) : IStatusRepository
{
    public async Task<IReadOnlyList<StatusFromDbResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var commandDefinition = new CommandDefinition(
            "public.get_all_statuses",
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var responses = await repository.CallProcedure<StatusFromDbResponse>(commandDefinition);

        return responses.ToList();
    }
}