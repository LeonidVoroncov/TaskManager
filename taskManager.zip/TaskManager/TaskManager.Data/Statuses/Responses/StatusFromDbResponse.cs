﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Statuses.Responses;

public record StatusFromDbResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("c_name")]
    public required string Name { get; init; }
}