﻿using TaskManager.Data.Statuses.Responses;

namespace TaskManager.Data.Statuses.Interfaces;

public interface IStatusRepository
{
    Task<IReadOnlyList<StatusFromDbResponse>> GetAll(CancellationToken cancellationToken = default);
}