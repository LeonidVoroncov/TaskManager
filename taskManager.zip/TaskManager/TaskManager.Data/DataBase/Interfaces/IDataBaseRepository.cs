﻿using Dapper;

namespace TaskManager.Data.DataBase.Interfaces;

public interface IDataBaseRepository
{
    Task<IEnumerable<TResult>> CallProcedure<TResult>(
        CommandDefinition commandDefinition
    );

    Task CallProcedure(
        CommandDefinition commandDefinition
    );
}