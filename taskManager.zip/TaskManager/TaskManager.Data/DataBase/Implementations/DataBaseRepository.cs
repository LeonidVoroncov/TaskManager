﻿using Dapper;
using Microsoft.Extensions.Logging;
using TaskManager.Data.DataBase.Interfaces;

namespace TaskManager.Data.DataBase.Implementations;

public class DataBaseRepository(
    DataBaseConnectionFactory dataBaseConnectionFactory,
    ILogger<DataBaseRepository> logger
) : IDataBaseRepository
{
    public async Task<IEnumerable<TResult>> CallProcedure<TResult>(CommandDefinition commandDefinition)
    {
        try
        {
            await using var connection = dataBaseConnectionFactory.CreateConnection();
            return await connection.QueryAsync<TResult>(commandDefinition);
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "An error occured while getting");
            throw new Exception("Не удается получить записи, попробуйте чуть позже");
        }
    }

    public async Task CallProcedure(CommandDefinition commandDefinition)
    {
        try
        {
            await using var connection = dataBaseConnectionFactory.CreateConnection();
            await connection.ExecuteAsync(commandDefinition);
        }
        catch (Exception exception)
        {
            logger.LogError(exception, "An error occured while getting");
            throw new Exception("Не удается получить записи, попробуйте чуть позже");
        }
    }
}