﻿using Npgsql;
using Microsoft.Extensions.Configuration;

namespace TaskManager.Data.DataBase.Implementations;

public class DataBaseConnectionFactory
{
    private readonly string? _connectionString;

    public DataBaseConnectionFactory(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("SqlConnection");
    }

    public NpgsqlConnection CreateConnection()
        => new(_connectionString);
}