﻿using Dapper;

namespace TaskManager.Data.DataBase.Extensions;

public static class DynamicParametersExtension
{
    public static DynamicParameters AddParam(
        this DynamicParameters dynamicParameters,
        string name,
        object? value
    )
    {
        dynamicParameters.Add(name, value);
        
        return dynamicParameters;
    }
}