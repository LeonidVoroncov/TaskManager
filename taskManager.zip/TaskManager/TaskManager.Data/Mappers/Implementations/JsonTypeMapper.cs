﻿using System.Data;
using System.Data.SqlTypes;
using System.Text.Json;
using Dapper;
using Npgsql;
using NpgsqlTypes;

namespace TaskManager.Data.Mappers.Implementations;

public class JsonTypeMapper<T>(JsonSerializerOptions? jsonSerializerOptions = null) : SqlMapper.TypeHandler<T?>
    where T : class?
{
    private readonly JsonSerializerOptions _jsonSerializerOptions = jsonSerializerOptions ?? JsonSerializerOptions.Default;

    public override void SetValue(
        IDbDataParameter parameter,
        T? value
    )
    {
        if (parameter is NpgsqlParameter npgsqlParameter)
        {
            npgsqlParameter.NpgsqlDbType = NpgsqlDbType.Json;
        }

        parameter.Value = JsonSerializer.Serialize(value, _jsonSerializerOptions);
    }

    public override T? Parse(object value)
    {
        if (value is string json)
        {
            return JsonSerializer.Deserialize<T>(json, _jsonSerializerOptions);
        }

        throw new SqlTypeException($"Detected string, but it was {value}");
    }
}