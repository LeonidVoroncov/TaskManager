﻿using System.Reflection;
using System.Text.Json.Serialization;
using Dapper;

namespace TaskManager.Data.Mappers.Implementations;

public class CustomPropertyTypeMapper
{
    public static CustomPropertyTypeMap Create(Type targetType)
    {
        return new CustomPropertyTypeMap(
            targetType,
            (type, name) =>
            {
                var propertyInfo = type
                    .GetProperties()
                    .FirstOrDefault(
                        propertyInfo =>
                        {
                            var attribute = propertyInfo.GetCustomAttribute<JsonPropertyNameAttribute>();

                            return name == attribute?.Name;
                        }
                    );

                return propertyInfo;
            }
        );
    }
}