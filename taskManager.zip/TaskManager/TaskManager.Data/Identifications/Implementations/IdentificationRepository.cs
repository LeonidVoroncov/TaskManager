﻿using System.Data;
using Dapper;
using TaskManager.Data.DataBase.Extensions;
using TaskManager.Data.DataBase.Interfaces;
using TaskManager.Data.Identifications.Interfaces;
using TaskManager.Data.Projects.Requests;

namespace TaskManager.Data.Identifications.Implementations;

public class IdentificationRepository(IDataBaseRepository repository) : IIdentificationRepository
{
    public async Task<bool> CheckUniquenessEmail(
        string email,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_email", email);
        
        var commandDefinition = new CommandDefinition(
            "public.check_user_exists_by_email",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var isUniqueEmail = (await repository.CallProcedure<int>(commandDefinition)).FirstOrDefault() == 0;
        
        return isUniqueEmail;
    }
}