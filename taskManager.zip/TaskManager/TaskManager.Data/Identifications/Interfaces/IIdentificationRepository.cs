﻿namespace TaskManager.Data.Identifications.Interfaces;

public interface IIdentificationRepository
{
    Task<bool> CheckUniquenessEmail(
        string email,
        CancellationToken cancellationToken = default
    );
}