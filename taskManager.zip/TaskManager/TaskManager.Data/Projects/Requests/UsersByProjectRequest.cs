﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace TaskManager.Data.Projects.Requests;

public record UsersByProjectRequest
{
    [FromRoute(Name = "project-id")]
    [BindRequired]
    public required int ProjectId { get; init; }
}