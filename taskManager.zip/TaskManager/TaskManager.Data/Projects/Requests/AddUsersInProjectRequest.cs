﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Projects.Requests;

public record AddUsersInProjectRequest
{
    [JsonPropertyName("userIds")]
    public  required int[] UserIds { get; init; }
    
    [JsonPropertyName("projectId")]
    public  required int ProjectId { get; init; }
}