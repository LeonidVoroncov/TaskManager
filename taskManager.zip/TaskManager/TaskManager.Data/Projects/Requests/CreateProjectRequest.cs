﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Projects.Requests;

public record CreateProjectRequest
{
    [JsonPropertyName("name")]
    public required string Name { get; init; }
    
    [JsonIgnore]
    public int UserCreatorId { get; set; }
    
    [JsonPropertyName("description")]
    public string? Description { get; init; }
    
    [JsonPropertyName("userIds")]
    public int[]? UserIds { get; init; }
}