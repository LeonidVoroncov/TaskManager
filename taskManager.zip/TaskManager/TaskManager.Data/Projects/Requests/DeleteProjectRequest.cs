﻿namespace TaskManager.Data.Projects.Requests;

public record DeleteProjectRequest();