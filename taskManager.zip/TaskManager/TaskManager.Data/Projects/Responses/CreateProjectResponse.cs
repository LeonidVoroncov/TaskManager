﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Projects.Responses;

public record CreateProjectResponse
{
    [JsonPropertyName("id")] 
    public required int Id { get; init; }
}