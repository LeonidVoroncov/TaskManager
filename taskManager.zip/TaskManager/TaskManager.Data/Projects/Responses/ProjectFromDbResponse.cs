﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Projects.Responses;

public record ProjectFromDbResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("c_name")]
    public required string Name { get; init; }
    
    [JsonPropertyName("id_user_creator")]
    public required int UserCreatorId { get; init; }
    
    [JsonPropertyName("c_description")]
    public string? Description { get; init; }
    
    [JsonPropertyName("c_users")]
    public UsersByProjectFromDbResponse[]? Users { get; init; }
}