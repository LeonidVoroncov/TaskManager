﻿using TaskManager.Data.Projects.Requests;
using TaskManager.Data.Projects.Responses;

namespace TaskManager.Data.Projects.Interfaces;

public interface IProjectRepository
{
    Task<CreateProjectResponse> Create(
        CreateProjectRequest request,
        CancellationToken cancellationToken = default
    );

    Task AddUsers(
        AddUsersInProjectRequest request,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyList<ProjectFromDbResponse>> GetAll(CancellationToken cancellationToken = default);

    Task<IReadOnlyList<UsersByProjectFromDbResponse>> GetUsersByProject(
        UsersByProjectRequest request,
        CancellationToken cancellationToken = default
    );
}