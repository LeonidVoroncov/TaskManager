﻿using System.Data;
using Dapper;
using TaskManager.Data.DataBase.Extensions;
using TaskManager.Data.DataBase.Interfaces;
using TaskManager.Data.Projects.Interfaces;
using TaskManager.Data.Projects.Requests;
using TaskManager.Data.Projects.Responses;

namespace TaskManager.Data.Projects.Implementations;

public class ProjectRepository(IDataBaseRepository repository) : IProjectRepository
{
    public async Task<CreateProjectResponse> Create(
        CreateProjectRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_name", request.Name)
            .AddParam("_id_user_creator", request.UserCreatorId)
            .AddParam("_description", request.Description);
        
        var commandDefinition = new CommandDefinition(
            "public.set_project",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var id = (await repository.CallProcedure<int>(commandDefinition)).FirstOrDefault();
        
        return new CreateProjectResponse
        {
            Id = id
        };
    }

    public async Task AddUsers(
        AddUsersInProjectRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_id_project", request.ProjectId)
            .AddParam("_id_user", request.UserIds);
        
        var commandDefinition = new CommandDefinition(
            "add_users_to_project",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        await repository.CallProcedure(commandDefinition);
    }
    
    public async Task<IReadOnlyList<ProjectFromDbResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var commandDefinition = new CommandDefinition(
            "public.get_all_projects_v2",
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var responses = await repository.CallProcedure<ProjectFromDbResponse>(commandDefinition);

        return responses.ToList();
    }

    public async Task<IReadOnlyList<UsersByProjectFromDbResponse>> GetUsersByProject(
        UsersByProjectRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_id_project", request.ProjectId);
        
        var commandDefinition = new CommandDefinition(
            "public.get_users_by_project",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var responses = await repository.CallProcedure<UsersByProjectFromDbResponse>(commandDefinition);

        return responses.ToList();
    }
}