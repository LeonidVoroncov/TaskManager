﻿namespace TaskManager.Data.Users.Requests;

public record AddUserReviewersToTaskRequest
{
    public required int TaskId { get; init; }
    
    public required int UserId { get; init; }
}