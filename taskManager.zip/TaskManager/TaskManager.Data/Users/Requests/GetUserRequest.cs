﻿namespace TaskManager.Data.Users.Requests;

public record GetUserRequest
{
    public required string Email { get; init; }
}