﻿namespace TaskManager.Data.Users.Requests;

public record GetUserReviewersTaskRequest
{
    public required int TaskId { get; init; }
}