﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Users.Responses;

public record GetUserReviewersResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("id_user")]
    public required int UserId { get; init; }
    
    [JsonPropertyName("id_task")]
    public required int TaskId { get; init; }
}