﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Users.Responses;

public record GetUserInfoResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("c_first_name")]
    public required string FirstName { get; init; }
    
    [JsonPropertyName("c_last_name")]
    public required string LastName { get; init; }
}