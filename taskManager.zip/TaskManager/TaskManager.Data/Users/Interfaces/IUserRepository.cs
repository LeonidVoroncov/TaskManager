﻿using TaskManager.Data.Users.Requests;
using TaskManager.Data.Users.Responses;

namespace TaskManager.Data.Users.Interfaces;

public interface IUserRepository
{
    Task<GetUserResponse?> GetUser(
        GetUserRequest request,
        CancellationToken cancellationToken = default
    );
    
    Task<GetUserResponse?> GetUserById(
        int id,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyList<GetUserReviewersResponse>> GetUserReviewersTask(
        GetUserReviewersTaskRequest taskRequest,
        CancellationToken cancellationToken = default
    );

    Task AddUserReviewersToTask(
        AddUserReviewersToTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyList<GetUserInfoResponse>> GetAll(CancellationToken cancellationToken = default);
}