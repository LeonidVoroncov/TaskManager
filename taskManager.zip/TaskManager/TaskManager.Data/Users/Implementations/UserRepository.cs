﻿using System.Data;
using Dapper;
using TaskManager.Data.DataBase.Extensions;
using TaskManager.Data.DataBase.Interfaces;
using TaskManager.Data.Users.Interfaces;
using TaskManager.Data.Users.Requests;
using TaskManager.Data.Users.Responses;

namespace TaskManager.Data.Users.Implementations;

public class UserRepository(IDataBaseRepository repository) : IUserRepository
{
    public async Task<GetUserResponse?> GetUser(
        GetUserRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters.AddParam("_email", request.Email);
        
        var commandDefinition = new CommandDefinition(
            "public.get_user_by_email",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var response = (await repository.CallProcedure<GetUserResponse>(commandDefinition)).FirstOrDefault();
        
        return response;
    }

    public async Task<GetUserResponse?> GetUserById(
        int id,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters.AddParam("_id", id);
        
        var commandDefinition = new CommandDefinition(
            "public.get_user_by_id",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var response = (await repository.CallProcedure<GetUserResponse>(commandDefinition)).FirstOrDefault();
        
        return response;
    }

    public async Task<IReadOnlyList<GetUserReviewersResponse>> GetUserReviewersTask(
        GetUserReviewersTaskRequest taskRequest,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_id_task", taskRequest.TaskId);
        
        var commandDefinition = new CommandDefinition(
            "public.get_reviewers_for_task",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        return (await repository.CallProcedure<GetUserReviewersResponse>(commandDefinition)).ToList();
    }
    
    public async Task AddUserReviewersToTask(
        AddUserReviewersToTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_id_task", request.TaskId)
            .AddParam("_id_user", request.UserId);
        
        var commandDefinition = new CommandDefinition(
            "public.add_user_reviewer_to_task",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        await repository.CallProcedure(commandDefinition);
    }

    public async Task<IReadOnlyList<GetUserInfoResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var commandDefinition = new CommandDefinition(
            "public.get_all_users",
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var response = await repository.CallProcedure<GetUserInfoResponse>(commandDefinition);
        
        return response.ToList();
    }
}