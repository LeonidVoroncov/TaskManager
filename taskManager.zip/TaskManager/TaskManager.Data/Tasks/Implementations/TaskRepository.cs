﻿using System.Data;
using System.IdentityModel.Tokens.Jwt;
using Dapper;
using TaskManager.Data.DataBase.Extensions;
using TaskManager.Data.DataBase.Interfaces;
using TaskManager.Data.Tasks.Interfaces;
using TaskManager.Data.Tasks.Requests;
using TaskManager.Data.Tasks.Responses;

namespace TaskManager.Data.Tasks.Implementations;

public class TaskRepository(IDataBaseRepository repository) : ITaskRepository
{
    public async Task<CreateTaskResponse> Create(
        CreateTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();
        
        parameters
            .AddParam("_id", request.Id)
            .AddParam("_id_project", request.ProjectId)
            .AddParam("_number", request.Number)
            .AddParam("_name", request.Name)
            .AddParam("_description", request.Description)
            .AddParam("_id_status", request.StatusId)
            .AddParam("_id_user_creator", request.UserCreatorId)
            .AddParam("_id_user_assigned", request.UserAssignedId)
            .AddParam("_deadline_date", new DateTimeOffset(request.DeadlineDate, TimeSpan.Zero))
            .AddParam("_files", request.Files)
            .AddParam("_chat", request.Chat)
            .AddParam("_links", request.Links);
        
        var commandDefinition = new CommandDefinition(
            "public.set_task",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var id = (await repository.CallProcedure<int>(commandDefinition)).FirstOrDefault();
        
        return new CreateTaskResponse
        {
            Id = id
        };
    }

    public async Task AssignUser(
        AssignUserOnTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();
        
        parameters
            .AddParam("_id_user", request.UserId)
            .AddParam("_id_task", request.TaskId);
        
        var commandDefinition = new CommandDefinition(
            "public.update_task_assigned_user",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        await repository.CallProcedure(commandDefinition);
    }

    public async Task SetStatus(SetStatusTaskRequest request, CancellationToken cancellationToken = default)
    {
        var parameters = new DynamicParameters();
        
        parameters
            .AddParam("_id_status", request.StatusId)
            .AddParam("_id_task", request.TaskId);
        
        var commandDefinition = new CommandDefinition(
            "public.update_task_status",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        await repository.CallProcedure(commandDefinition);
    }

    public async Task Update(
        UpdateTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_id_task", request.Id)
            .AddParam("_name", request.Name)
            .AddParam("_description", request.Description)
            .AddParam("_id_status", request.StatusId)
            .AddParam("_id_user_assigned", request.UserAssignedId)
            .AddParam("_deadline_date", new DateTimeOffset(request.DeadlineDate, TimeSpan.Zero))
            .AddParam("_files", request.Files);
        
        var commandDefinition = new CommandDefinition(
            "public.update_task_details",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        await repository.CallProcedure(commandDefinition);
    }

    public async Task Delete(DeleteTaskRequest request, CancellationToken cancellationToken = default)
    {
        var parameters = new DynamicParameters();

        parameters
            .AddParam("_id_task", request.Id);
        
        var commandDefinition = new CommandDefinition(
            "public.delete_task",
            parameters,
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );

        await repository.CallProcedure(commandDefinition);
    }

    public async Task<IReadOnlyList<TaskFromDbResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var commandDefinition = new CommandDefinition(
            "public.get_all_tasks",
            commandType: CommandType.StoredProcedure,
            cancellationToken: cancellationToken
        );
        
        var responses = await repository.CallProcedure<TaskFromDbResponse>(commandDefinition);

        return responses.ToList();
    }
}