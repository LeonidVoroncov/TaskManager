﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Tasks.Responses;

public record CreateTaskResponse
{
    [JsonPropertyName("id")] 
    public required int Id { get; init; }
}