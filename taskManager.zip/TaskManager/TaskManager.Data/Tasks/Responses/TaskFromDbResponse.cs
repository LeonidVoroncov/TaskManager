﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Tasks.Responses;

public record TaskFromDbResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("id_project")]
    public required int ProjectId { get; init; }
    
    [JsonPropertyName("c_number")]
    public required string Number { get; init; }
    
    [JsonPropertyName("c_name")]
    public required string Name { get; init; }
    
    [JsonPropertyName("c_description")]
    public required string Description { get; init; }
    
    [JsonPropertyName("id_status")]
    public required int StatusId { get; init; }
    
    [JsonPropertyName("id_user_creator")]
    public required int UserCreatorId { get; init; }
    
    [JsonPropertyName("id_user_assigned")]
    public int? UserAssignedId { get; init; }
    
    [JsonPropertyName("c_deadline_date")]
    public DateTime DeadlineDate { get; init; }
    
    [JsonPropertyName("c_files")]
    public string? Files { get; init; }
    
    [JsonPropertyName("c_links")]
    public string? Links { get; init; }
    
    [JsonPropertyName("c_chat")]
    public string? Chat { get; init; }
}