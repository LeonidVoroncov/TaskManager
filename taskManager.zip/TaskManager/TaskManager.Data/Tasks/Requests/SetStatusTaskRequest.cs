﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Tasks.Requests;

public record SetStatusTaskRequest
{
    [JsonPropertyName("taskId")]
    public required int TaskId { get; init; }
    
    [JsonPropertyName("statusId")]
    public required int StatusId { get; init; }
}