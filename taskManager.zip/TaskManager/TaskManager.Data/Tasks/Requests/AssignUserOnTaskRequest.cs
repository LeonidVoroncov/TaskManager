﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Tasks.Requests;

public record AssignUserOnTaskRequest
{
    [JsonPropertyName("taskId")]
    public required int TaskId { get; init; }
    
    [JsonPropertyName("userId")]
    public required int UserId { get; init; }
}