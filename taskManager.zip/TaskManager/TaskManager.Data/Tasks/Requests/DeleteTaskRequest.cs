﻿using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Mvc;

namespace TaskManager.Data.Tasks.Requests;

public record DeleteTaskRequest
{
    [FromRoute(Name = "task-id")]
    public required int Id { get; init; }
}