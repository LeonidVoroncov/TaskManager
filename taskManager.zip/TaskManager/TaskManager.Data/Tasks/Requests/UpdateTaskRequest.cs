﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Tasks.Requests;

public record UpdateTaskRequest
{
    [JsonPropertyName("id")] 
    public required int Id { get; init; }
    
    [JsonPropertyName("name")]
    public required string Name { get; init; }
    
    [JsonPropertyName("description")]
    public required string Description { get; init; }
    
    [JsonPropertyName("statusId")]
    public required int StatusId { get; init; }
    
    [JsonPropertyName("userAssignedId")]
    public int? UserAssignedId { get; init; }
    
    [JsonPropertyName("deadlineDate")]
    public DateTime DeadlineDate { get; init; }
    
    [JsonPropertyName("files")]
    public string? Files { get; init; }
}