﻿using System.Text.Json.Serialization;

namespace TaskManager.Data.Tasks.Requests;

public record CreateTaskRequest
{
    [JsonIgnore]
    public int? Id { get; init; }
    
    [JsonPropertyName("projectId")]
    public required int ProjectId { get; init; }
    
    [JsonPropertyName("number")]
    public required string Number { get; init; }
    
    [JsonPropertyName("name")]
    public required string Name { get; init; }
    
    [JsonPropertyName("description")]
    public required string Description { get; init; }
    
    [JsonPropertyName("statusId")]
    public required int StatusId { get; init; }
    
    [JsonIgnore]
    public int UserCreatorId { get; set; }
    
    [JsonPropertyName("userAssignedId")]
    public int? UserAssignedId { get; init; }
    
    [JsonPropertyName("deadlineDate")]
    public DateTime DeadlineDate { get; init; }
    
    [JsonPropertyName("files")]
    public string? Files { get; init; }
    
    [JsonPropertyName("links")]
    public string? Links { get; init; }
    
    [JsonPropertyName("chat")]
    public string? Chat { get; init; }
    
    [JsonPropertyName("userReviewerIds")]
    public IReadOnlyList<int>? UserReviewerIds { get; init; }
}