﻿using TaskManager.Data.Tasks.Requests;
using TaskManager.Data.Tasks.Responses;

namespace TaskManager.Data.Tasks.Interfaces;

public interface ITaskRepository
{
    Task<CreateTaskResponse> Create(
        CreateTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task AssignUser(
        AssignUserOnTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task SetStatus(
        SetStatusTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task Update(
        UpdateTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task Delete(
        DeleteTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyList<TaskFromDbResponse>> GetAll(CancellationToken cancellationToken = default);
}