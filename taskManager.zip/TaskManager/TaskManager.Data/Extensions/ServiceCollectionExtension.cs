﻿using System.Data;
using System.Data.SqlTypes;
using System.Text.Json;
using Dapper;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;
using NpgsqlTypes;
using TaskManager.Data.Authentications.Implementations;
using TaskManager.Data.Authentications.Interfaces;
using TaskManager.Data.DataBase.Implementations;
using TaskManager.Data.DataBase.Interfaces;
using TaskManager.Data.Identifications.Implementations;
using TaskManager.Data.Identifications.Interfaces;
using TaskManager.Data.Mappers.Implementations;
using TaskManager.Data.Projects.Implementations;
using TaskManager.Data.Projects.Interfaces;
using TaskManager.Data.Projects.Responses;
using TaskManager.Data.Statuses.Implementations;
using TaskManager.Data.Statuses.Interfaces;
using TaskManager.Data.Tasks.Implementations;
using TaskManager.Data.Tasks.Interfaces;
using TaskManager.Data.Users.Implementations;
using TaskManager.Data.Users.Interfaces;

namespace TaskManager.Data.Extensions;

public static class ServiceCollectionExtension
{
    public static IServiceCollection AddRepository(this IServiceCollection serviceCollection)
    {
        SqlMapper.AddTypeHandler<UsersByProjectFromDbResponse[]>(new JsonTypeMapper<UsersByProjectFromDbResponse[]>()!);
        
        return serviceCollection
            .AddDbAccess()
            .AddSingleton<ITaskRepository, TaskRepository>()
            .AddSingleton<IProjectRepository, ProjectRepository>()
            .AddSingleton<IIdentificationRepository, IdentificationRepository>()
            .AddSingleton<IAuthenticationRepository, AuthenticationRepository>()
            .AddSingleton<IUserRepository, UserRepository>()
            .AddSingleton<IStatusRepository, StatusRepository>();
    }
    
    private static IServiceCollection AddDbAccess(this IServiceCollection serviceCollection)
    {
        AppContext.SetSwitch("Npgsql.EnableStoredProcedureCompatMode", true);
        
        SqlMapper.TypeMapProvider = CustomPropertyTypeMapper.Create;
        
        return serviceCollection
            .AddSingleton<DataBaseConnectionFactory>()
            .AddSingleton<IDataBaseRepository, DataBaseRepository>();
    }
}

