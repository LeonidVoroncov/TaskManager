﻿using TaskManager.Data.Tasks.Requests;
using TaskManager.Data.Tasks.Responses;
using TaskManager.Domain.Tasks.Responses;

namespace TaskManager.Domain.Tasks.Interfaces;

public interface ITaskService
{
    Task<CreateTaskResponse> Create(
        CreateTaskRequest request,
        string token,
        CancellationToken cancellationToken = default
    );

    Task AssignUser(
        AssignUserOnTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task SetStatus(
        SetStatusTaskRequest request,
        CancellationToken cancellationToken = default
    );
    
    Task Update(
        UpdateTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task Delete(
        DeleteTaskRequest request,
        CancellationToken cancellationToken = default
    );

    Task<IReadOnlyList<TaskResponse>> GetAll(CancellationToken cancellationToken = default);
}