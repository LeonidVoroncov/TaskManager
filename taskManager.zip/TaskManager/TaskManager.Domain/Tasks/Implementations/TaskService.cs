﻿using System.IdentityModel.Tokens.Jwt;
using Microsoft.Extensions.Logging;
using TaskManager.Data.Projects.Interfaces;
using TaskManager.Data.Tasks.Interfaces;
using TaskManager.Data.Tasks.Requests;
using TaskManager.Data.Tasks.Responses;
using TaskManager.Data.Users.Interfaces;
using TaskManager.Data.Users.Requests;
using TaskManager.Domain.Tasks.Interfaces;
using TaskManager.Domain.Tasks.Responses;
using TaskManager.Domain.Users.Responses;

namespace TaskManager.Domain.Tasks.Implementations;

public class TaskService(
    ITaskRepository repository,
    IUserRepository userRepository,
    IProjectRepository projectRepository,
    ILogger<TaskService> logger
) : ITaskService
{
    public async Task<CreateTaskResponse> Create(
        CreateTaskRequest request,
        string token,
        CancellationToken cancellationToken = default
    )
    {
        var concatToken = token[7..];

        var handler = new JwtSecurityTokenHandler();

        if (!handler.CanReadToken(concatToken))
        {
            throw new ArgumentException("Invalid token");
        }

        var jwtToken = handler.ReadJwtToken(concatToken);

        var userIdString = jwtToken.Claims.FirstOrDefault(c => c.Type == "id")?.Value;

        if (userIdString != null && int.TryParse(userIdString, out var userId))
        {
            request.UserCreatorId = userId;
        }
        
        var result = await repository.Create(request, cancellationToken);

        if (request.UserReviewerIds is null)
        {
            return result;
        }

        var taskId = result.Id;
        
        foreach (var userReviewerId in request.UserReviewerIds)
        {
            try
            {
                await userRepository.AddUserReviewersToTask(
                    new AddUserReviewersToTaskRequest
                    {
                        TaskId = result.Id,
                        UserId = userReviewerId
                    },
                    cancellationToken
                );
            }
            catch
            {
                logger.LogError("Сan`t save reviewers TaskId: {taskId}, UserId: {userId}", taskId, userReviewerId);
            }
        }
        
        return result;
    }

    public Task AssignUser(
        AssignUserOnTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        return repository.AssignUser(request, cancellationToken);
    }

    public Task SetStatus(
        SetStatusTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        return repository.SetStatus(request, cancellationToken);
    }

    public Task Update(
        UpdateTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        return repository.Update(request, cancellationToken);
    }

    public Task Delete(
        DeleteTaskRequest request,
        CancellationToken cancellationToken = default
    )
    {
        return repository.Delete(request, cancellationToken);
    }

    public async Task<IReadOnlyList<TaskResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var tasks = await repository.GetAll(cancellationToken);
        var projects = await projectRepository.GetAll(cancellationToken);
        
        var tasksResponses = new List<TaskResponse>();
        
        foreach (var task in tasks)
        {
            var userReviewers = new List<UserResponse>();
            
            try
            {
                var userReviewerIds = (await userRepository.GetUserReviewersTask(new GetUserReviewersTaskRequest
                        {
                            TaskId = task.Id
                        },
                        cancellationToken
                    ))
                    ?.Select(userReviewersResponse => userReviewersResponse.UserId)
                    ?.ToList();

                if (userReviewerIds is not null)
                {
                    foreach (var userReviewerId in userReviewerIds)
                    {
                        var userReviewer = await userRepository.GetUserById(userReviewerId, cancellationToken);

                        if (userReviewer is null)
                        {
                            continue;
                        }
                        
                        userReviewers.Add(new UserResponse
                        {
                            Id = userReviewer.Id,
                            FirstName = userReviewer.FirstName,
                            LastName = userReviewer.LastName
                        });
                    }
                }
            }
            catch
            {
                logger.LogError("Error get reviewers");
            }

            string? userAssignedName = null;

            if (task.UserAssignedId != null)
            {
                var userAssigned = await userRepository.GetUserById(task.UserAssignedId.Value, cancellationToken);

                userAssignedName = $"{userAssigned?.FirstName} {userAssigned?.LastName}";
            }
            
            var taskResponse = new TaskResponse
            {
                Id = task.Id,
                ProjectId = task.ProjectId,
                ProjectName = projects.FirstOrDefault(project => project.Id == task.ProjectId)?.Name,
                Number = task.Number,
                Name = task.Name,
                Description = task.Description,
                StatusId = task.StatusId,
                UserCreatorId = task.UserCreatorId,
                UserAssignedId = task.UserAssignedId,
                UserAssignedName = userAssignedName,
                DeadlineDate = task.DeadlineDate,
                Files = task.Files,
                Links = task.Links,
                Chat = task.Chat,
                UserReviewers = userReviewers
            };
            
            tasksResponses.Add(taskResponse);
        }

        return tasksResponses;
    }
}