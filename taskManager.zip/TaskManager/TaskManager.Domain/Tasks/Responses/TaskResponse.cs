﻿using System.Text.Json.Serialization;
using TaskManager.Domain.Users.Responses;

namespace TaskManager.Domain.Tasks.Responses;

public record TaskResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("projectId")]
    public required int ProjectId { get; init; }
    
    [JsonPropertyName("projectName")]
    public string? ProjectName { get; init; }
    
    [JsonPropertyName("number")]
    public required string Number { get; init; }
    
    [JsonPropertyName("name")]
    public required string Name { get; init; }
    
    [JsonPropertyName("description")]
    public required string Description { get; init; }
    
    [JsonPropertyName("statusId")]
    public required int StatusId { get; init; }
    
    [JsonPropertyName("userCreatorId")]
    public required int UserCreatorId { get; init; }
    
    [JsonPropertyName("userAssignedId")]
    public int? UserAssignedId { get; init; }
    
    [JsonPropertyName("userAssignedName")]
    public string? UserAssignedName { get; init; }
    
    [JsonPropertyName("deadlineDate")]
    public DateTime DeadlineDate { get; init; }
    
    [JsonPropertyName("files")]
    public string? Files { get; init; }
    
    [JsonPropertyName("links")]
    public string? Links { get; init; }
    
    [JsonPropertyName("chat")]
    public string? Chat { get; init; }
    
    [JsonPropertyName("userReviewers")]
    public IReadOnlyList<UserResponse>? UserReviewers { get; init; }
}