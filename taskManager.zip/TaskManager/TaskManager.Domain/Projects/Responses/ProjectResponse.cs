﻿using System.Text.Json.Serialization;

namespace TaskManager.Domain.Projects.Responses;

public record ProjectResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("name")]
    public required string Name { get; init; }
    
    [JsonPropertyName("userCreatorId")]
    public required int UserCreatorId { get; init; }
    
    [JsonPropertyName("description")]
    public string? Description { get; init; }
    
    [JsonPropertyName("users")]
    public IReadOnlyList<UsersByProjectResponse>? Users { get; init; }
}