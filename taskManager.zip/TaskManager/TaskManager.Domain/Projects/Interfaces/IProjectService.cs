﻿using TaskManager.Data.Projects.Requests;
using TaskManager.Data.Projects.Responses;
using TaskManager.Domain.Projects.Responses;

namespace TaskManager.Domain.Projects.Interfaces;

public interface IProjectService
{
    Task<CreateProjectResponse> Create(
        CreateProjectRequest request,
        string token,
        CancellationToken cancellationToken
    );
    
    Task AddUsers(
        AddUsersInProjectRequest request,
        CancellationToken cancellationToken = default
    );

    Task Update(
        UpdateProjectRequest request,
        CancellationToken cancellationToken
    );

    Task Delete(
        DeleteProjectRequest request,
        CancellationToken cancellationToken
    );

    Task<IReadOnlyList<ProjectResponse>> GetAll(CancellationToken cancellationToken = default);

    Task<IReadOnlyList<UsersByProjectResponse>> GetUsersByProject(
        UsersByProjectRequest request,
        CancellationToken cancellationToken = default
    );
}