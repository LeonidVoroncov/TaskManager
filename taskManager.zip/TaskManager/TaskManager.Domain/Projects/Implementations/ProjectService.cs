﻿using System.IdentityModel.Tokens.Jwt;
using TaskManager.Data.Projects.Interfaces;
using TaskManager.Data.Projects.Requests;
using TaskManager.Data.Projects.Responses;
using TaskManager.Domain.Projects.Interfaces;
using TaskManager.Domain.Projects.Responses;

namespace TaskManager.Domain.Projects.Implementations;

public class ProjectService(IProjectRepository repository) : IProjectService
{
    public async Task<CreateProjectResponse> Create(
        CreateProjectRequest request,
        string token,
        CancellationToken cancellationToken
    )
    {
        var concatToken = token[7..];

        var handler = new JwtSecurityTokenHandler();

        if (!handler.CanReadToken(concatToken))
        {
            throw new ArgumentException("Invalid token");
        }

        var jwtToken = handler.ReadJwtToken(concatToken);

        var userIdString = jwtToken.Claims.FirstOrDefault(c => c.Type == "id")?.Value;

        if (userIdString != null && int.TryParse(userIdString, out var userId))
        {
            request.UserCreatorId = userId;
        }

        var response = await repository.Create(request, cancellationToken);

        if (request.UserIds is not null)
            await AddUsers(new AddUsersInProjectRequest
                {
                    UserIds = request.UserIds,
                    ProjectId = response.Id
                }, cancellationToken
            );

        return response;
    }

    public Task AddUsers(
        AddUsersInProjectRequest request,
        CancellationToken cancellationToken = default
    )
    {
        return repository.AddUsers(request, cancellationToken);
    }

    public Task Update(UpdateProjectRequest request, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public Task Delete(DeleteProjectRequest request, CancellationToken cancellationToken)
    {
        throw new NotImplementedException();
    }

    public async Task<IReadOnlyList<ProjectResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var projectResponses = await repository.GetAll(cancellationToken);
        
        return projectResponses.Select(project => new ProjectResponse
        {
            Id = project.Id,
            Name = project.Name,
            UserCreatorId = project.UserCreatorId,
            Description = project.Description,
            Users = project.Users?.Select(users => new UsersByProjectResponse
            {
                Id = users.Id,
                FirstName = users.FirstName,
                LastName = users.LastName
            }).ToList()
        }).ToList();
    }

    public async Task<IReadOnlyList<UsersByProjectResponse>> GetUsersByProject(
        UsersByProjectRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var responses = await repository.GetUsersByProject(request, cancellationToken);

        return responses.Select(user =>
            new UsersByProjectResponse
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName
            }
        ).ToList();
    }
}