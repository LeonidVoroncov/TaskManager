﻿using System.Text.Json.Serialization;

namespace TaskManager.Domain.Statuses.Responses;

public record StatusResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("name")]
    public required string Name { get; init; }
}