﻿using TaskManager.Data.Statuses.Interfaces;
using TaskManager.Domain.Statuses.Interfaces;
using TaskManager.Domain.Statuses.Responses;

namespace TaskManager.Domain.Statuses.Implementations;

public class StatusService(IStatusRepository repository) : IStatusService
{
    public async Task<IReadOnlyList<StatusResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var responses = await repository.GetAll(cancellationToken);

        return responses.Select(project => new StatusResponse
        {
            Id = project.Id,
            Name = project.Name
        }).ToList();
    }
}