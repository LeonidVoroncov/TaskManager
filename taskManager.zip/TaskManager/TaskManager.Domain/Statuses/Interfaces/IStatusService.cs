﻿using TaskManager.Domain.Statuses.Responses;

namespace TaskManager.Domain.Statuses.Interfaces;

public interface IStatusService
{
    Task<IReadOnlyList<StatusResponse>> GetAll(CancellationToken cancellationToken = default);
}