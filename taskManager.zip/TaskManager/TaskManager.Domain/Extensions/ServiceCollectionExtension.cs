﻿using Microsoft.Extensions.DependencyInjection;
using TaskManager.Data.Extensions;
using TaskManager.Domain.Authentications.Implementations;
using TaskManager.Domain.Authentications.Interfaces;
using TaskManager.Domain.Encryption.Implementations;
using TaskManager.Domain.Encryption.Interfaces;
using TaskManager.Domain.Identifications.Implementations;
using TaskManager.Domain.Identifications.Interfaces;
using TaskManager.Domain.Projects.Implementations;
using TaskManager.Domain.Projects.Interfaces;
using TaskManager.Domain.Statuses.Implementations;
using TaskManager.Domain.Statuses.Interfaces;
using TaskManager.Domain.Tasks.Implementations;
using TaskManager.Domain.Tasks.Interfaces;
using TaskManager.Domain.Users.Implementations;
using TaskManager.Domain.Users.Interfaces;

namespace TaskManager.Domain.Extensions;

public static class ServiceCollectionExtension
{
    public static IServiceCollection AddServices(
        this IServiceCollection serviceCollection)
    {
        return serviceCollection
            .AddRepository()
            .AddSingleton<ITaskService, TaskService>()
            .AddSingleton<IProjectService, ProjectService>()
            .AddSingleton<IAuthenticationService, AuthenticationService>()
            .AddSingleton<IIdentificationService, IdentificationService>()
            .AddSingleton<IUserService, UserService>()
            .AddSingleton<IEncryptionService, EncryptionService>()
            .AddSingleton<IStatusService, StatusService>();
    }
}