﻿using Microsoft.AspNetCore.Authentication;
using TaskManager.Data.Authentications.Interfaces;
using TaskManager.Data.Users.Interfaces;
using TaskManager.Data.Users.Requests;
using TaskManager.Domain.Authentications.Requests;
using TaskManager.Domain.Encryption.Interfaces;
using TaskManager.Domain.Identifications.Interfaces;
using IAuthenticationService = TaskManager.Domain.Authentications.Interfaces.IAuthenticationService;
using UserRegisterRequest = TaskManager.Data.Authentications.Requests.UserRegisterRequest;

namespace TaskManager.Domain.Authentications.Implementations;

public class AuthenticationService(
    IAuthenticationRepository repository,
    IUserRepository userRepository,
    IEncryptionService encryptionService,
    IIdentificationService identificationService
) : IAuthenticationService
{
    public async Task<int> Login(
        UserLoginRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var user = await userRepository.GetUser(
            new GetUserRequest { Email = request.Email },
            cancellationToken
        );

        if (user is null)
        {
            throw new AuthenticationFailureException("Incorrect password");
        }
        
        var hashPassword = await encryptionService.Encrypt(request.Password);

        if (user.Password != hashPassword)
        {
            throw new AuthenticationFailureException("Incorrect password");
        }
        
        return user.Id;
    }

    public async Task<int> Register(
        Requests.UserRegisterRequest request,
        CancellationToken cancellationToken = default
    )
    {
        var isUniqueEmail = await identificationService.CheckUniquenessEmail(request.Email, cancellationToken);

        if (!isUniqueEmail)
        {
            throw new Exception("The user with this email already exists");
        }
        
        var hashPassword = await encryptionService.Encrypt(request.Password);
        
        var user = new UserRegisterRequest
        {
            UserName = request.UserName,
            FirstName = request.FirstName,
            LastName = request.LastName,
            Password = hashPassword,
            Email = request.Email
        };

        return await repository.CreateUser(user, cancellationToken);
    }
}