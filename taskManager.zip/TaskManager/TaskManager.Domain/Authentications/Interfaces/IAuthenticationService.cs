﻿using TaskManager.Domain.Authentications.Requests;

namespace TaskManager.Domain.Authentications.Interfaces;

public interface IAuthenticationService
{
    Task<int> Login(
        UserLoginRequest request,
        CancellationToken cancellationToken = default
    );
    
    Task<int> Register(
        UserRegisterRequest request, 
        CancellationToken cancellationToken = default
    );
}