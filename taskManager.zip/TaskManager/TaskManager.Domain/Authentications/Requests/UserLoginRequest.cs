﻿using System.Text.Json.Serialization;

namespace TaskManager.Domain.Authentications.Requests;

public record UserLoginRequest
{
    [JsonPropertyName("email")]
    public required string Email { get; init; }
    
    [JsonPropertyName("password")]
    public required string Password { get; init; }
}