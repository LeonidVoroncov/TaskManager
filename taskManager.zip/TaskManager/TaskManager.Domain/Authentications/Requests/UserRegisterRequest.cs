﻿using System.Text.Json.Serialization;
using Microsoft.AspNetCore.Http;

namespace TaskManager.Domain.Authentications.Requests;

public record UserRegisterRequest
{
    [JsonPropertyName("userName")] 
    public required string UserName { get; init; }

    [JsonPropertyName("firstName")] 
    public required string FirstName { get; init; }

    [JsonPropertyName("lastName")] 
    public required string LastName { get; init; }

    [JsonPropertyName("password")] 
    public required string Password { get; init; }
    
    [JsonPropertyName("passwordConfirm")]
    public required string PasswordConfirm { get; init; }
    
    [JsonPropertyName("email")]
    public required string Email { get; init; }

    [JsonPropertyName("photo")] 
    public IFormFile? Photo { get; init; }
}