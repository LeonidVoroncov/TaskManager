﻿namespace TaskManager.Domain.Identifications.Interfaces;

public interface IIdentificationService
{
    Task<bool> CheckUniquenessEmail(
        string email,
        CancellationToken cancellationToken = default
    );
}