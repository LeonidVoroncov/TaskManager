﻿using TaskManager.Data.Identifications.Interfaces;
using TaskManager.Domain.Identifications.Interfaces;

namespace TaskManager.Domain.Identifications.Implementations;

public class IdentificationService(IIdentificationRepository repository) : IIdentificationService
{
    public async Task<bool> CheckUniquenessEmail(
        string email,
        CancellationToken cancellationToken = default
    )
    {
        return await repository.CheckUniquenessEmail(email, cancellationToken);
    }
}