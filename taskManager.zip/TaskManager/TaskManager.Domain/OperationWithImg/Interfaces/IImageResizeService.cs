﻿namespace TaskManager.Domain.OperationWithImg.Interfaces;

public interface IImageResizeService
{
    
}