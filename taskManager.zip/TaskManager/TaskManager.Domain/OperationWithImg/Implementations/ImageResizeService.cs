﻿using TaskManager.Domain.OperationWithImg.Interfaces;

namespace TaskManager.Domain.OperationWithImg.Implementations;

public class ImageResizeService : IImageResizeService // зарегать singleton
{
    public void Resize()
    {
        // валидируем обрезаем и возвращаем
    }
}

public class SaveImg
{
    public void Save()
    {
        // получаем обрезанное изображение и даем новое название, сохраняем в папке, возвращаем название. 
    }
}

public interface IImageProfile
{
    string Folder { get; }

    int Width { get; }

    int Height { get; }

    int MaxSizeBytes { get; }

    IEnumerable<string> AllowedExtensions { get; }
}

public class UserImageProfile : IImageProfile // зарегать singleton
{
    private const int Mb = 1048576;

    public string Folder => "ProductImage";

    public int Width => 100;

    public int Height => 100;

    public int MaxSizeBytes => 10 * Mb;

    public IEnumerable<string> AllowedExtensions { get; } = new List<string> { ".jpg", ".jpeg", ".png", ".gif" };
}