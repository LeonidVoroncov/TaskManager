﻿using System.Security.Cryptography;
using System.Text;
using TaskManager.Domain.Encryption.Interfaces;

namespace TaskManager.Domain.Encryption.Implementations;

public class EncryptionService : IEncryptionService
{
    private static readonly byte[] Key = "C7emJUjdO423uz3CuLI4"u8.ToArray();
    
    public async Task<string> Encrypt(string value)
    {
        var strStreamOne = new MemoryStream(Encoding.UTF8.GetBytes(value));
        byte[] hashOne;
        
        using (var hmac = new HMACSHA256(Key))
        {
            hashOne = await hmac.ComputeHashAsync(strStreamOne);
        }
        
        var hashAsString = Convert.ToHexString(hashOne);

        return hashAsString;
    }
}