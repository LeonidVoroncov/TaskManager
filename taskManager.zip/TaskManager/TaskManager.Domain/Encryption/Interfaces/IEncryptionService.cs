﻿namespace TaskManager.Domain.Encryption.Interfaces;

public interface IEncryptionService
{
    Task<string> Encrypt(string value);
}