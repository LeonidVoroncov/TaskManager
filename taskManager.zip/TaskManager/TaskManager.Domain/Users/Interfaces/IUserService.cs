﻿using TaskManager.Domain.Users.Responses;

namespace TaskManager.Domain.Users.Interfaces;

public interface IUserService
{
    Task<IReadOnlyList<UserResponse>> GetAll(CancellationToken cancellationToken = default);
}