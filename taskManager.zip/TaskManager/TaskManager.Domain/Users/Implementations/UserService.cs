﻿using TaskManager.Data.Users.Interfaces;
using TaskManager.Domain.Users.Interfaces;
using TaskManager.Domain.Users.Responses;

namespace TaskManager.Domain.Users.Implementations;

public class UserService(IUserRepository repository) : IUserService
{
    public async Task<IReadOnlyList<UserResponse>> GetAll(CancellationToken cancellationToken = default)
    {
        var responses = await repository.GetAll(cancellationToken);
        return responses
            .Select(user => new UserResponse
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName
            }).ToList();
    }
}