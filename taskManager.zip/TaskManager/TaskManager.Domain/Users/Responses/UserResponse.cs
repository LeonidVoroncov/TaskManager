﻿using System.Text.Json.Serialization;

namespace TaskManager.Domain.Users.Responses;

public record UserResponse
{
    [JsonPropertyName("id")]
    public required int Id { get; init; }
    
    [JsonPropertyName("firstName")]
    public required string FirstName { get; init; }
    
    [JsonPropertyName("lastName")]
    public required string LastName { get; init; }
}