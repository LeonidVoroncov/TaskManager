﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManager.Data.Projects.Requests;
using TaskManager.Data.Projects.Responses;
using TaskManager.Domain.Projects.Interfaces;
using TaskManager.Domain.Projects.Responses;

namespace TaskManager.Api.Controllers;

[Authorize]
[Route("projects")]
[ApiController]
public class ProjectController(
    ILogger<ProjectController> logger,
    IProjectService service
) : ControllerBase
{
    // создание проекта
    [HttpPost]
    public async Task<ActionResult<CreateProjectResponse>> Create(
        [FromBody] CreateProjectRequest request,
        CancellationToken cancellationToken
    )
    {
        var token = HttpContext.Request.Headers.Authorization;
        
        var response = await service.Create(request, token, cancellationToken);
        
        return Created(string.Empty, response);
    }
    
    // назначение пользователя на проект 
    [HttpPost("add-users")]
    public async Task<ActionResult<CreateProjectResponse>> AddUsers(
        [FromBody] AddUsersInProjectRequest request,
        CancellationToken cancellationToken
    )
    {
        await service.AddUsers(request, cancellationToken);
        
        return Accepted();
    }
    
    [HttpPut]
    public async Task<IActionResult> Update(
        [FromBody] UpdateProjectRequest request,
        CancellationToken cancellationToken
    )
    {
        await service.Update(request, cancellationToken);
        
        return Accepted();
    }
    
    [HttpDelete]
    public async Task<IActionResult> Delete(
        [FromQuery] DeleteProjectRequest request,
        CancellationToken cancellationToken
    )
    {
        await service.Delete(request, cancellationToken);
        
        return NoContent();
    }
    
    // получение всех проектов
    [HttpGet("all")]
    public async Task<ActionResult<IReadOnlyList<ProjectResponse>>> GetAll(CancellationToken cancellationToken)
    {
        return Ok(await service.GetAll(cancellationToken));
    }
    
    // получение пользователей по проекту
    [HttpGet("{project-id:int}/users")]
    public async Task<ActionResult<IReadOnlyList<UsersByProjectResponse>>> GetUsersByProject(
        UsersByProjectRequest request,
        CancellationToken cancellationToken
    )
    {
        return Ok(await service.GetUsersByProject(request, cancellationToken));
    }
}