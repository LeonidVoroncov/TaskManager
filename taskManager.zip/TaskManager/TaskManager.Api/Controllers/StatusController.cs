﻿using Microsoft.AspNetCore.Mvc;
using TaskManager.Domain.Statuses.Interfaces;
using TaskManager.Domain.Statuses.Responses;

namespace TaskManager.Api.Controllers;

// [Authorize]
[Route("statuses")]
[ApiController]
public class StatusController(IStatusService service) : ControllerBase
{
    // получение всех статусов
    [HttpGet("all")]
    public async Task<ActionResult<IReadOnlyList<StatusResponse>>> GetAll(CancellationToken cancellationToken)
    {
        return Ok(await service.GetAll(cancellationToken));
    }
}