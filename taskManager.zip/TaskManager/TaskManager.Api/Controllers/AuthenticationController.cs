﻿using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using TaskManager.Api.Validators;
using TaskManager.Domain.Authentications.Interfaces;
using TaskManager.Domain.Authentications.Requests;
using AuthorizationOptions = TaskManager.Api.Authentications.Models.AuthorizationOptions;

namespace TaskManager.Api.Controllers;

[Authorize]
[ApiController]
public class AuthenticationController(IAuthenticationService service) : ControllerBase
{
    [AllowAnonymous]
    [UserRegisterValidation]
    [HttpPost("register")]
    public async Task<IActionResult> Register(
        [FromBody] UserRegisterRequest request,
        CancellationToken cancellationToken
    )
    {
        var userId = await service.Register(request, cancellationToken);
        
        return Created(string.Empty, CreateJwtToken(request.Email, userId));
    }
    
    [AllowAnonymous]
    [HttpPost("login")]
    public async Task<IActionResult> Login(
        [FromBody] UserLoginRequest request,
        CancellationToken cancellationToken
    )
    {
        var userId = await service.Login(request, cancellationToken);
        
        return Ok(CreateJwtToken(request.Email, userId));
    }

    private static string CreateJwtToken(
        string email,
        int id
    )
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.Email, email), 
            new("id", id.ToString())
        };
        
        var jwt = new JwtSecurityToken(
            issuer: AuthorizationOptions.Issuer,
            audience: AuthorizationOptions.Audience,
            claims: claims,
            expires: DateTime.UtcNow.Add(TimeSpan.FromDays(15)),
            signingCredentials: new SigningCredentials(AuthorizationOptions.GetSymmetricSecurityKey(), SecurityAlgorithms.HmacSha256));
            
        var token = new JwtSecurityTokenHandler().WriteToken(jwt);
        
        return token;
    }
}