﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManager.Data.Tasks.Requests;
using TaskManager.Data.Tasks.Responses;
using TaskManager.Domain.Tasks.Interfaces;
using TaskManager.Domain.Tasks.Responses;

namespace TaskManager.Api.Controllers;

[Authorize]
[Route("tasks")]
[ApiController]
public class TaskController(ITaskService service) : ControllerBase
{
    // создание задачи
    [HttpPost]
    public async Task<ActionResult<CreateTaskResponse>> Create(
        [FromBody] CreateTaskRequest request,
        CancellationToken cancellationToken
    )
    {
        var token = HttpContext.Request.Headers.Authorization;
        
        var response = await service.Create(request, token, cancellationToken);
        
        return Created(string.Empty, response);
    }

    // изменить назначенного пользователя 
    [HttpPut("set-assigned-user")]
    public async Task<IActionResult> AssignUser(AssignUserOnTaskRequest request)
    {
        await service.AssignUser(request);
        
        return Accepted();
    }
    
    // изменить статус задачи
    [HttpPut("set-status")]
    public async Task<IActionResult> SetStatus(SetStatusTaskRequest request)
    {
        await service.SetStatus(request);
        
        return Accepted();
    }
    
    // обновить задачу
    [HttpPut]
    public async Task<IActionResult> Update(
        [FromBody] UpdateTaskRequest request,
        CancellationToken cancellationToken
    )
    {
        await service.Update(request, cancellationToken);
        
        return Accepted();
    }
    
    // удалить задачу
    [HttpDelete("{task-id}")]
    public async Task<IActionResult> Delete(
        DeleteTaskRequest request,
        CancellationToken cancellationToken
    )
    {
        await service.Delete(request, cancellationToken);
        
        return NoContent();
    }

    // получение всех задач
    [HttpGet("all")]
    public async Task<ActionResult<IReadOnlyList<TaskResponse>>> GetAll(CancellationToken cancellationToken)
    {
        return Ok(await service.GetAll(cancellationToken));
    }
}