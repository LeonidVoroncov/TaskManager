﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TaskManager.Domain.Users.Interfaces;
using TaskManager.Domain.Users.Responses;

namespace TaskManager.Api.Controllers;

[Authorize]
[Route("users")]
[ApiController]
public class UserInfoController(IUserService service) : ControllerBase
{
    // получение всех пользователей
    [HttpGet("all")]
    public async Task<ActionResult<IReadOnlyList<UserResponse>>> GetAll(CancellationToken cancellationToken)
    {
        return Ok(await service.GetAll(cancellationToken));
    }
}