﻿using FluentValidation;
using TaskManager.Domain.Authentications.Requests;

namespace TaskManager.Api.Validators;

public class UserRegisterValidator : AbstractValidator<UserRegisterRequest>
{
    public UserRegisterValidator()
    {
        RuleFor(x => x.Email)
            .EmailAddress()
            .WithMessage("Invalid email");
        
        RuleFor(x => x)
            .Must(x => x.Password == x.PasswordConfirm)
            .WithMessage("Passwords don't match");
    }
}