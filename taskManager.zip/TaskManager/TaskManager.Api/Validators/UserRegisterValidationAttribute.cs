﻿using FluentValidation;
using Microsoft.AspNetCore.Mvc.Filters;
using TaskManager.Domain.Authentications.Requests;

namespace TaskManager.Api.Validators;

public class UserRegisterValidationAttribute : ActionFilterAttribute
{
    public override void OnActionExecuting(ActionExecutingContext context)
    {
        foreach (var argument in context.ActionArguments)
        {
            if (argument.Value is UserRegisterRequest value)
            {
                var resultValid = context
                    .HttpContext.RequestServices
                    .GetRequiredService<UserRegisterValidator>()
                    .Validate(value);

                if (!resultValid.IsValid)
                {
                    throw new ValidationException(
                        resultValid.Errors.First()
                            .ErrorMessage
                    );
                }
            }
        }

        base.OnActionExecuting(context);
    }
}