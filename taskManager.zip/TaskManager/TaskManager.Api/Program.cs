using TaskManager.Api.Authentications.Extensions;
using TaskManager.Api.Extensions;

var builder = WebApplication.CreateSlimBuilder(args);

builder.Services
    .AddCors()
    .AddAuthorization()
    .AddEndpointsApiExplorer()
    .AddSwaggerGen()
    .AddComponents()
    .AddJwtAuthorization();

builder.Services.AddControllers();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app
    .UseCors(corsPolicyBuilder => corsPolicyBuilder
        .AllowAnyOrigin()
        .AllowAnyMethod()
        .AllowAnyHeader())
    .UseRouting()
    .UseAuthentication()
    .UseAuthorization()
    .UseEndpoints(endpoints => { endpoints.MapControllers(); });

app.Run();