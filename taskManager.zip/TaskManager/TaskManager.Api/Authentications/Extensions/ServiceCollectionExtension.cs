﻿using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.IdentityModel.Tokens;
using TaskManager.Api.Authentications.Models;

namespace TaskManager.Api.Authentications.Extensions;

public static class ServiceCollectionExtension
{
    public static IServiceCollection AddJwtAuthorization(this IServiceCollection serviceCollection)
    {
        serviceCollection
            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidIssuer = AuthorizationOptions.Issuer,
                    ValidateAudience = true,
                    ValidAudience = AuthorizationOptions.Audience,
                    ValidateLifetime = true,
                    IssuerSigningKey = AuthorizationOptions.GetSymmetricSecurityKey(),
                    ValidateIssuerSigningKey = true,
                };
            });

        return serviceCollection;
    }
}