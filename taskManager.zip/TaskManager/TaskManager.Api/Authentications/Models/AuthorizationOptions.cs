﻿using System.Text;
using Microsoft.IdentityModel.Tokens;

namespace TaskManager.Api.Authentications.Models;

public record AuthorizationOptions
{
    public const string Issuer = "MyAuthServer";

    public const string Audience = "MyAuthClient";

    private const string Key = "xUr6Ypb661ZwZ3ZU33t7XaQyWRmSTlzGSGaAtXA4";

    public static SymmetricSecurityKey GetSymmetricSecurityKey()
    {
        return new SymmetricSecurityKey(Encoding.UTF8.GetBytes(Key));
    }
}