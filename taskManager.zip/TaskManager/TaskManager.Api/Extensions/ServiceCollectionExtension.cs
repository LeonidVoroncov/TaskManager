﻿using TaskManager.Api.Validators;
using TaskManager.Domain.Extensions;

namespace TaskManager.Api.Extensions;

public static class ServiceCollectionExtension
{
    public static IServiceCollection AddComponents(this IServiceCollection services)
    {
        return services
            .AddServices()
            .AddValidators();
    }
    
    private static IServiceCollection AddValidators(this IServiceCollection serviceCollection)
    {
        return serviceCollection
            .AddSingleton<UserRegisterValidator>();
    }
}