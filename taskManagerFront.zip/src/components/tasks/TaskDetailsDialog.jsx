
import { useState, useEffect } from "react";
import { format } from "date-fns";
import { Pen, Trash, CalendarIcon, Users, Link, Paperclip, CheckSquare, UserCheck, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogClose,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { useToast } from "@/hooks/use-toast";
import { Checkbox } from "@/components/ui/checkbox";
import axios from 'axios';
import config from '/config';

const apiUrl = config.apiUrl;

export function TaskDetailsDialog({ task, isOpen, onOpenChange, onDelete, onUpdate }) {
  const [editMode, setEditMode] = useState(false);
  const [editedTask, setEditedTask] = useState({});
  const [date, setDate] = useState(null);
  const { toast } = useToast();
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [statuses, setStatus] = useState([]);

  useEffect(() => {
    if (task) {
      setEditedTask({ ...task });
      setDate(task.dueDate ? new Date(task.dueDate) : null);
    }
  }, [task]);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const statusResponse = await axios.get(`${apiUrl}/statuses/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });

        setStatus(statusResponse.data);
      }
      catch(error) {
        console.error('Ошибка при получении статусов:', error);
      }
    };

    fetchTasks();
  }, []);

  const handleSaveChanges = () => {
    onUpdate(editedTask);
    setEditMode(false);
    toast({
      title: "Задача обновлена",
      description: "Изменения успешно сохранены",
    });
  };

  const handleDelete = async () => {
    try {
      await axios.delete(`${apiUrl}/tasks/${task.id}`, {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });

      onDelete(task.id);
      onOpenChange(false);
      toast({
        title: "Задача удалена",
        description: "Задача была успешно удалена",
        variant: "destructive",
      });
    }
    catch (error) {
      console.error('Ошибка при получении статусов:', error);
    }
  };

  const formatDate = (dateString) => {
    try {
      return new Date(dateString).toLocaleDateString();
    } catch (e) {
      return dateString;
    }
  };

  const addChecklistItem = () => {
    const newChecklistItems = editedTask.checklistItems || [];
    setEditedTask({
      ...editedTask,
      checklistItems: [...newChecklistItems, { text: "", checked: false }]
    });
  };

  const addLink = () => {
    const newLinks = editedTask.links || [];
    setEditedTask({
      ...editedTask,
      links: [...newLinks, ""]
    });
  };

  if (!task) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent className="overflow-y-auto grid justify-items-start" 
        style={{ width: '70vw', maxWidth: '400px', height: '80vh', maxHeight: '80vh' }}>
        <DialogHeader>
          <DialogTitle>
            {editMode ? (
              <Input
                value={editedTask.title || ""}
                onChange={(e) => setEditedTask({ ...editedTask, title: e.target.value })}
                className="text-xl font-bold"
              />
            ) : (
              task.name
            )}
          </DialogTitle>
        </DialogHeader>

        <div className="grid gap-4 grid-cols-4">
          {/* Project and Assignee */}
          <div className="grid grid-cols-2 md:grid-cols-2 gap-4">
            <div>
              <Label>Проект</Label>
              {editMode ? (
                <Select
                  value={editedTask.project || ""}
                  onValueChange={(value) => setEditedTask({ ...editedTask, project: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите проект" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Веб-сайт компании">Веб-сайт компании</SelectItem>
                    <SelectItem value="CRM Система">CRM Система</SelectItem>
                    <SelectItem value="Мобильное приложение">Мобильное приложение</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <div className="text-base">{task.description}</div>
              )}
            </div>

            <div>
              <Label>Ответственный</Label>
              {editMode ? (
                <Select
                  value={editedTask.assignee || ""}
                  onValueChange={(value) => setEditedTask({ ...editedTask, assignee: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите ответственного" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Александр К.">Александр К.</SelectItem>
                    <SelectItem value="Мария П.">Мария П.</SelectItem>
                    <SelectItem value="Дмитрий С.">Дмитрий С.</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <div className="text-base">{task.userAssignedName}</div>
              )}
            </div>
          </div>

          {/* Deadline date and Status */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label>Срок выполнения</Label>
              {editMode ? (
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, 'PP') : <span>Выберите дату</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => {
                        setDate(date);
                        setEditedTask({ ...editedTask, dueDate: date.toISOString().split('T')[0] });
                      }}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              ) : (
                <div className="text-base">{formatDate(task.deadlineDate)}</div>
              )}
            </div>

            <div>
              <Label>Статус</Label>
              {editMode ? (
                <Select
                  value={editedTask.statusId || ""}
                  onValueChange={(value) => setEditedTask({ ...editedTask, status: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите статус" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Ожидает">Ожидает</SelectItem>
                    <SelectItem value="В процессе">В процессе</SelectItem>
                    <SelectItem value="Завершено">Завершено</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                  ${task.statusId === 4 ? 'bg-blue-100 text-blue-800' : 
                    task.statusId === 3 ? 'bg-red-100 text-red-800' : 
                    task.statusId === 2 ? 'bg-orange-100 text-orange-800' : 
                    'bg-yellow-100 text-yellow-800'}`}>
                  {(statuses?.find(status => status.id === task.statusId))?.name}
                </span>
              )}
            </div>
          </div>

          {/* Description */}
          <div>
            <Label>Описание</Label>
            {editMode ? (
              <Textarea
                value={editedTask.description || ""}
                onChange={(e) => setEditedTask({ ...editedTask, description: e.target.value })}
                className="h-24"
              />
            ) : (
              <div className="text-base">
                {task.description || "Описание отсутствует"}
              </div>
            )}
          </div>

          {/* Checklist */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <CheckSquare className="h-4 w-4" />
              <Label>Чек-лист</Label>
            </div>
            <div className="space-y-2">
              {editMode ? (
                <>
                  {(editedTask.checklistItems || []).map((item, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Checkbox
                        checked={item.checked}
                        onCheckedChange={(checked) => {
                          const newItems = [...(editedTask.checklistItems || [])];
                          newItems[index].checked = checked;
                          setEditedTask({ ...editedTask, checklistItems: newItems });
                        }}
                      />
                      <Input
                        value={item.text}
                        onChange={(e) => {
                          const newItems = [...(editedTask.checklistItems || [])];
                          newItems[index].text = e.target.value;
                          setEditedTask({ ...editedTask, checklistItems: newItems });
                        }}
                        placeholder="Элемент чек-листа"
                      />
                    </div>
                  ))}
                  <Button type="button" variant="outline" onClick={addChecklistItem} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Добавить пункт
                  </Button>
                </>
              ) : (
                <>
                  {task.checklistItems && task.checklistItems.length > 0 ? (
                    task.checklistItems.map((item, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Checkbox checked={item.checked} disabled />
                        <span className={item.checked ? "line-through text-muted-foreground" : ""}>
                          {item.text}
                        </span>
                      </div>
                    ))
                  ) : (
                    <div className="text-muted-foreground">Нет элементов чек-листа</div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Observers */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <UserCheck className="h-4 w-4" />
              <Label>Наблюдатели</Label>
            </div>
            {editMode ? (
              <Select
                value={editedTask.observers || []}
                onValueChange={(value) => setEditedTask({ ...editedTask, observers: Array.isArray(value) ? value : [value] })}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Добавить наблюдателей" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Александр К.">Александр К.</SelectItem>
                  <SelectItem value="Мария П.">Мария П.</SelectItem>
                  <SelectItem value="Дмитрий С.">Дмитрий С.</SelectItem>
                </SelectContent>
              </Select>
            ) : (
              <div className="text-base">
                {task.userReviewers && task.userReviewers.length > 0 ? (
                  task.userReviewers.map(person => `${person.firstName} ${person.lastName}`).join(', ')
                ) : (
                  <span className="text-muted-foreground">Нет наблюдателей</span>
                )}
              </div>
            )}
          </div>

          {/* Links */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Link className="h-4 w-4" />
              <Label>Ссылки</Label>
            </div>
            <div className="space-y-2">
              {editMode ? (
                <>
                  {(editedTask.links || []).map((link, index) => (
                    <div key={index} className="flex items-center gap-2">
                      <Input
                        value={link}
                        onChange={(e) => {
                          const newLinks = [...(editedTask.links || [])];
                          newLinks[index] = e.target.value;
                          setEditedTask({ ...editedTask, links: newLinks });
                        }}
                        placeholder="https://"
                      />
                    </div>
                  ))}
                  <Button type="button" variant="outline" onClick={addLink} size="sm">
                    <Link className="h-4 w-4 mr-2" />
                    Добавить ссылку
                  </Button>
                </>
              ) : (
                <>
                  {task.links && task.links.length > 0 ? (
                    task.links?.split(',')?.map((link, index) => (
                      <div key={index} className="py-1">
                        <a href={link} target="_blank" rel="noopener noreferrer" className="text-blue-500 hover:underline flex items-center">
                          <Link className="h-4 w-4 mr-2" />
                          {link}
                        </a>
                      </div>
                    ))
                  ) : (
                    <div className="text-muted-foreground">Нет ссылок</div>
                  )}
                </>
              )}
            </div>
          </div>

          {/* Files */}
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Paperclip className="h-4 w-4" />
              <Label>Файлы</Label>
            </div>
            {editMode ? (
              <div className="mt-2">
                <div className="flex items-center justify-center w-full">
                  <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-dashed rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Paperclip className="w-8 h-8 mb-2 text-gray-500" />
                      <p className="text-sm text-gray-500">
                        <span className="font-semibold">Нажмите для загрузки</span> или перетащите файлы
                      </p>
                    </div>
                    <input
                      type="file"
                      className="hidden"
                      multiple
                      onChange={(e) => setEditedTask({ ...editedTask, files: Array.from(e.target.files || []) })}
                    />
                  </label>
                </div>
                {(editedTask.files || []).length > 0 && (
                  <div className="mt-4 space-y-2">
                    {(editedTask.files || []).map((file, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="flex items-center">
                          <Paperclip className="h-4 w-4 mr-2" />
                          <span>{file.name || file}</span>
                        </div>
                        <Button 
                          variant="ghost" 
                          size="sm" 
                          onClick={() => {
                            const newFiles = [...(editedTask.files || [])];
                            newFiles.splice(index, 1);
                            setEditedTask({ ...editedTask, files: newFiles });
                          }}
                        >
                          <Trash className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ) : (
              <div className="space-y-2">
                {task.files && task.files.length > 0 ? (
                  task.files?.map((file, index) => (
                    <div key={index} className="flex items-center">
                      <Paperclip className="h-4 w-4 mr-2" />
                      <span>{typeof file === 'string' ? file : file.name}</span>
                    </div>
                  ))
                ) : (
                  <div className="text-muted-foreground">Нет прикрепленных файлов</div>
                )}
              </div>
            )}
          </div>
        </div>

        <DialogFooter className="mt-6">
          {editMode ? (
            <>
              <Button variant="outline" onClick={() => setEditMode(false)}>
                Отменить
              </Button>
              <Button onClick={handleSaveChanges}>
                Сохранить
              </Button>
            </>
          ) : (
            <>
              <Button variant="outline" onClick={() => setEditMode(true)}>
                <Pen className="mr-2 h-4 w-4" />
                Редактировать
              </Button>
              <Button variant="destructive" onClick={handleDelete}>
                <Trash className="mr-2 h-4 w-4" />
                Удалить
              </Button>
            </>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
