import { useState, useEffect } from "react";
import { Plus, Link, Paperclip, CalendarIcon, Users } from "lucide-react";
import { format } from "date-fns";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import axios from 'axios';
import config from '/config';
import { useToast } from "@/hooks/use-toast";

const apiUrl = config.apiUrl;

export function CreateTaskDialog() {
  const [taskData, setTaskData] = useState({
    title: "",
    description: "",
    checklistItems: [{ text: "", checked: false }],
    status: "",
    deadline: null,
    project: "",
    assignee: "",
    observers: "",
    files: [],
    links: [""],
  });
  const [selectedTeamMembers, setSelectedTeamMembers] = useState([]);
  const [statuses, setStatus] = useState([]);
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]);
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [open, setOpen] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const statusResponse = await axios.get(`${apiUrl}/statuses/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });

        setStatus(statusResponse.data);
      }
      catch(error) {
        console.error('Ошибка при получении статусов:', error);
      }

      try {
        const projectResponse = await axios.get(`${apiUrl}/projects/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });

        setProjects(projectResponse.data);
      }
      catch(error) {
        console.error('Ошибка при получении проектов:', error);
      }
    };

    fetchTasks();
  }, []);

  useEffect(() => {
    const fetchTasks = async () => {
      try 
      {
        if (taskData.project == "" || taskData.project == null){
          setUsers([]);
          return;
        }

        const projectResponse = await axios.get(`${apiUrl}/projects/${taskData.project}/users`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });
  
        setUsers(projectResponse.data);
      }
      catch
      {
        toast({
          title: "Ошибка получения проектов",
          variant: "destructive",
        });
      }
    }

    fetchTasks();
  }, [taskData.project]);

  const [date, setDate] = useState()

  const addChecklistItem = () => {
    setTaskData(prev => ({
      ...prev,
      checklistItems: [...prev.checklistItems, { text: "", checked: false }]
    }));
  };

  const addLink = () => {
    setTaskData(prev => ({
      ...prev,
      links: [...prev.links, ""]
    }));
  };

  const handleAddTeamMember = (memberId) => {
    const memberToAdd = users.find(member => member.id === memberId);
    if (memberToAdd && !selectedTeamMembers.find(m => m.id === memberId)) {
      const newMembers = [...selectedTeamMembers, memberToAdd];
      setSelectedTeamMembers(newMembers);
      setTaskData(prev => ({
        ...prev,
        observers: newMembers.map(member => member.id)
      }));
    }
  };

  const removeTeamMember = (memberId) => {
    const newMembers = selectedTeamMembers.filter(member => member.id !== memberId);
    setSelectedTeamMembers(newMembers);
    setTaskData(prev => ({
      ...prev,
      observers: newMembers.map(member => member.id)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const request = {
        projectId: parseInt(taskData.project),
        name: taskData.title,
        description: taskData.description,
        statusId: parseInt(taskData.status),
        userAssignedId: parseInt(taskData.assignee),
        deadlineDate: taskData.deadline,
        links: taskData.links.toString(),
        chat: null,
        number: "1",
        userReviewerIds: taskData.observers
      };

      console.log(request);

      const response = await axios.post(`${apiUrl}/tasks`, request, {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });

      if (response.status === 201) {
        location.reload();
        setOpen(false);
        toast({
          title: "Задача создана"
        });
      }
    }
    catch {
      toast({
        title: "Ошибка отправки",
        description: "Проверьте данные и попробуйте снова.",
        variant: "destructive",
      });

      return;
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button>
          <Plus className="mr-2 h-4 w-4" />
          Новая задача
        </Button>
      </DialogTrigger>
      <DialogContent 
        className="overflow-y-auto" 
        style={{ width: '70vw', maxWidth: '70vw', height: '80vh', maxHeight: '80vh' }}
      >
        <DialogHeader>
          <DialogTitle>Создать новую задачу</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Название</Label>
              <Input
                id="title"
                value={taskData.title}
                onChange={(e) => setTaskData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Введите название задачи"
                required
              />
            </div>

            <div>
              <Label htmlFor="description">Описание</Label>
              <Textarea
                id="description"
                value={taskData.description}
                onChange={(e) => setTaskData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Опишите задачу"
                required
              />
            </div>

            <div>
              <Label>Чек-лист</Label>
              <div className="space-y-2">
                {taskData.checklistItems.map((item, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Checkbox
                      checked={item.checked}
                      onCheckedChange={(checked) => {
                        const newItems = [...taskData.checklistItems];
                        newItems[index].checked = checked;
                        setTaskData(prev => ({ ...prev, checklistItems: newItems }));
                      }}
                    />
                    <Input
                      value={item.text}
                      onChange={(e) => {
                        const newItems = [...taskData.checklistItems];
                        newItems[index].text = e.target.value;
                        setTaskData(prev => ({ ...prev, checklistItems: newItems }));
                      }}
                      placeholder="Элемент чек-листа"
                    />
                  </div>
                ))}
                <Button type="button" variant="outline" onClick={addChecklistItem}>
                  <Plus className="h-4 w-4 mr-2" />
                  Добавить пункт
                </Button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Статус</Label>
                <Select
                  value={taskData.status}
                  onValueChange={(value) => setTaskData(prev => ({ ...prev, status: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите статус" />
                  </SelectTrigger>
                  <SelectContent>
                    {
                      statuses?.map((item) => (
                        <SelectItem key={item.id} value={item.id.toString()}>{item.name}</SelectItem>
                      ))
                    }
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Дедлайн</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button variant="outline" className="w-full justify-start text-left">
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {date ? format(date, 'PP') : <span>Выберите дату</span>}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={date}
                      onSelect={(date) => {
                        setDate(date);
                        setTaskData(prev => ({ ...prev, deadline: date }));
                      }}
                      initialFocus
                      className="p-3 pointer-events-auto"
                      required
                    />
                  </PopoverContent>
                </Popover>
              </div>

              <div>
                <Label>Проект</Label>
                <Select
                  value={taskData.project}
                  onValueChange={(value) => setTaskData(prev => ({ ...prev, project: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Выберите проект" />
                  </SelectTrigger>
                  <SelectContent>
                    {
                      projects?.map((item, index) => (
                        <SelectItem key={item.id} value={item.id.toString()}>{item.name}</SelectItem>
                      ))
                    }
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label>Ответственный</Label>
                <Select
                  value={taskData.assignee}
                  onValueChange={(value) => setTaskData(prev => ({ ...prev, assignee: value }))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Назначить ответственного" />
                  </SelectTrigger>
                  <SelectContent>
                  {users?.length > 0 ? (
                    users.map((item) => (
                      <SelectItem key={item.id} value={item.id.toString()}>
                        {item.firstName} {item.lastName}
                      </SelectItem>
                    ))
                    ) : (
                      <SelectItem value="no-users" disabled>
                        Нет людей
                      </SelectItem>
                  )}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Наблюдатели</Label>
              <div className="flex flex-wrap gap-2 mb-3">
                {selectedTeamMembers.map((member) => (
                  <div 
                    key={member.id}
                    className="flex items-center gap-1 bg-secondary px-2 py-1 rounded-full text-sm"
                  >
                    <span>{member.firstName} {member.lastName}</span>
                    <button 
                      type="button" 
                      onClick={() => removeTeamMember(member.id)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
              <Select onValueChange={handleAddTeamMember} className="mt-4">
                <SelectTrigger>
                  <SelectValue placeholder="Добавить участника" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((member) => (
                    <SelectItem 
                      key={member.id} 
                      value={member.id}
                      disabled={selectedTeamMembers.some(m => m.id === member.id)}
                    >
                      {member.firstName} {member.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label>Ссылки</Label>
              <div className="space-y-2">
                {taskData.links.map((link, index) => (
                  <div key={index} className="flex items-center gap-2">
                    <Input
                      value={link}
                      onChange={(e) => {
                        const newLinks = [...taskData.links];
                        newLinks[index] = e.target.value;
                        setTaskData(prev => ({ ...prev, links: newLinks }));
                      }}
                      placeholder="https://"
                    />
                  </div>
                ))}
                <Button type="button" variant="outline" onClick={addLink}>
                  <Link className="h-4 w-4 mr-2" />
                  Добавить ссылку
                </Button>
              </div>
            </div>

            <div>
              <Label>Файлы</Label>
              <div className="mt-2">
                <div className="flex items-center justify-center w-full">
                  <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-800">
                    <div className="flex flex-col items-center justify-center pt-5 pb-6">
                      <Paperclip className="w-8 h-8 mb-4 text-gray-500" />
                      <p className="mb-2 text-sm text-gray-500">
                        <span className="font-semibold">Нажмите для загрузки</span> или перетащите файлы
                      </p>
                    </div>
                    <input
                      type="file"
                      className="hidden"
                      multiple
                      onChange={(e) => setTaskData(prev => ({ ...prev, files: Array.from(e.target.files || []) }))}
                    />
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4 mt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              Отмена
            </Button>
            <Button type="submit">
              Создать задачу
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
