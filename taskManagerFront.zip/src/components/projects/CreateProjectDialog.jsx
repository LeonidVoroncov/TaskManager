
import { useState, useEffect } from "react";
import { FolderKanban, Users, Plus } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import axios from 'axios';
import config from '/config';

const apiUrl = config.apiUrl;

export function CreateProjectDialog({ onProjectCreated }) {
  const [projectData, setProjectData] = useState({
    title: "",
    description: "",
    team: [],
  });

  const [selectedTeamMembers, setSelectedTeamMembers] = useState([]);
  const [open, setOpen] = useState(false);
  const { toast } = useToast();
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get(`${apiUrl}/users/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });

        setUsers(response.data);
      }
      catch(error) {
        console.error('Ошибка при получении пользователей:', error);
      }
    };

    fetchTasks();
  }, []);

  const handleAddTeamMember = (memberId) => {
    const memberToAdd = users.find(member => member.id === memberId);
    if (memberToAdd && !selectedTeamMembers.find(m => m.id === memberId)) {
      const newMembers = [...selectedTeamMembers, memberToAdd];
      setSelectedTeamMembers(newMembers);
      setProjectData(prev => ({
        ...prev,
        team: newMembers.map(member => member.id)
      }));
    }
  };

  const removeTeamMember = (memberId) => {
    const newMembers = selectedTeamMembers.filter(member => member.id !== memberId);
    setSelectedTeamMembers(newMembers);
    setProjectData(prev => ({
      ...prev,
      team: newMembers.map(member => member.id)
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const request = {
        name: projectData.title,
        description: projectData.description,
        userIds: projectData.team,
      };

      const response = await axios.post(`${apiUrl}/projects`, request, {
        headers: {
          "Authorization": `Bearer ${token}`
        }
      });

      if (response.status === 201) {
        location.reload();
        setProjectData({
          title: "",
          description: "",
          team: [],
        });
        setOpen(false);
        toast({
          title: "Проект создан"
        });
      }
    }
    catch (error) {
      console.error('Ошибка при создании проекта:', error);
      toast({
        title: "Ошибка отправки",
        description: "Проверьте данные и попробуйте снова.",
        variant: "destructive",
      });

      return;
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button onClick={() => setOpen(true)}>
          <Plus className="mr-2 h-4 w-4" />
          Новый проект
        </Button>
      </DialogTrigger>
      <DialogContent 
        className="w-[70vw] max-w-[70vw] h-[80vh] max-h-[80vh] overflow-y-auto" 
        style={{ width: '70vw', maxWidth: '70vw' }}
      >
        <DialogHeader>
          <DialogTitle>Создать новый проект</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-6 mt-4">
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Название проекта</Label>
              <Input
                id="title"
                value={projectData.title}
                onChange={(e) => setProjectData(prev => ({ ...prev, title: e.target.value }))}
                placeholder="Введите название проекта"
                required
              />
            </div>

            <div>
              <Label htmlFor="description">Описание</Label>
              <Textarea
                id="description"
                value={projectData.description}
                onChange={(e) => setProjectData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Опишите проект"
                required
              />
            </div>

            <div>
              <Label>Участники проекта</Label>
              <div className="flex flex-wrap gap-2 mb-3">
                {selectedTeamMembers.map((member) => (
                  <div 
                    key={member.id}
                    className="flex items-center gap-1 bg-secondary px-2 py-1 rounded-full text-sm"
                  >
                    <span>{member.firstName} {member.lastName}</span>
                    <button 
                      type="button" 
                      onClick={() => removeTeamMember(member.id)}
                      className="text-muted-foreground hover:text-foreground"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
              <Select onValueChange={handleAddTeamMember} className="mt-4">
                <SelectTrigger>
                  <SelectValue placeholder="Добавить участника" />
                </SelectTrigger>
                <SelectContent>
                  {users.map((member) => (
                    <SelectItem 
                      key={member.id} 
                      value={member.id}
                      disabled={selectedTeamMembers.some(m => m.id === member.id)}
                    >
                      {member.firstName} {member.lastName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex justify-end gap-4 mt-4">
            <Button 
              type="button" 
              variant="outline" 
              onClick={() => setOpen(false)}
            >
              Отмена
            </Button>
            <Button 
              type="submit"
              disabled={!projectData.title || !projectData.description || selectedTeamMembers.length === 0}
            >
              Создать проект
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
