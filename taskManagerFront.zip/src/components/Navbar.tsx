import React, { useState, useEffect } from "react";
import { Link, useLocation, Navigate, useNavigate } from "react-router-dom";
import { LayoutGrid, CheckSquare, FolderKanban, LogIn } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button"

export const Navbar = () => {
  const location = useLocation();
  const [isScrolled, setIsScrolled] = useState(false);
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  const navigate = useNavigate();

  useEffect(() => {
      const fetchProjects = () => {
        if(token){
          setIsLoggedIn(true);
        }
      };
  
      fetchProjects();
    }, []);

  const Logout = () => {
    localStorage.removeItem("token");

    setIsLoggedIn(false);

    return navigate("/");
  }

  return (
    <nav
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300 bg-white",
        isScrolled ? "bg-white/80 backdrop-blur-md shadow-sm" : "shadow-sm"
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="text-xl font-bold">
            TaskManager
          </Link>
          <div className="flex items-center space-x-4">
            <NavLink to="/tasks" icon={CheckSquare}>
              Tasks
            </NavLink>
            <NavLink to="/projects" icon={FolderKanban}>
              Projects
            </NavLink>
            {
              isLoggedIn
              ? <Button onClick={Logout} type="button" variant="outline">
                  Logout
                </Button>
              : <NavLink to="/auth" icon={LogIn}>
                  Login
                </NavLink>
            }
          </div>
        </div>
      </div>
    </nav>
  );
};

const NavLink = ({ 
  to, 
  children, 
  icon: Icon 
}: { 
  to: string; 
  children: React.ReactNode; 
  icon: React.ComponentType<any>; 
}) => {
  const location = useLocation();
  const isActive = location.pathname === to;

  return (
    <Link
      to={to}
      className={cn(
        "flex items-center space-x-2 px-4 py-2 rounded-lg transition-all duration-200",
        isActive 
          ? "bg-primary text-primary-foreground" 
          : "hover:bg-secondary"
      )}
    >
      <Icon className="w-4 h-4" />
      <span>{children}</span>
    </Link>
  );
};