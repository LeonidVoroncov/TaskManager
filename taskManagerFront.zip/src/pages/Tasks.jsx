
// import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { CreateTaskDialog } from "@/components/tasks/CreateTaskDialog";
import { TaskDetailsDialog } from "@/components/tasks/TaskDetailsDialog";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { CheckSquare, Clock, Users, Calendar, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '/config';

const apiUrl = config.apiUrl;

const mockTasks = [
  {
    id: 1,
    title: "Разработка дизайна",
    project: "Веб-сайт компании",
    assignee: "Александр К.",
    dueDate: "2024-03-20",
    status: "В процессе",
    description: "Разработка пользовательского интерфейса для главной страницы и основных разделов сайта компании.",
    checklistItems: [
      { text: "Создать макеты", checked: true },
      { text: "Согласовать с командой", checked: false },
      { text: "Подготовить ассеты", checked: false }
    ],
    observers: ["Мария П.", "Дмитрий С."],
    links: ["https://figma.com/design-project", "https://example.com/resources"],
    files: ["design-mockup.jpg", "colors.pdf"]
  },
  {
    id: 2,
    title: "Настройка базы данных",
    project: "CRM Система",
    assignee: "Мария П.",
    dueDate: "2024-03-15",
    status: "Ожидает",
    description: "Создание и настройка базы данных для новой CRM системы, включая миграцию данных из старой системы.",
    checklistItems: [
      { text: "Спроектировать структуру", checked: true },
      { text: "Миграция данных", checked: false }
    ],
    observers: ["Александр К."],
    links: ["https://dbdiagram.io/schema"],
    files: ["db-schema.sql"]
  },
  {
    id: 3,
    title: "Тестирование API",
    project: "Мобильное приложение",
    assignee: "Дмитрий С.",
    dueDate: "2024-03-18",
    status: "Завершено",
    description: "Проведение тестирования API для взаимодействия мобильного приложения с серверной частью.",
    checklistItems: [
      { text: "Составить тест кейсы", checked: true },
      { text: "Провести нагрузочное тестирование", checked: true },
      { text: "Документировать результаты", checked: true }
    ],
    observers: [],
    links: ["https://postman.com/collection", "https://github.com/project/issues/123"],
    files: ["test-results.xlsx", "api-documentation.pdf"]
  },
];

export default function Tasks() {
  const [sortBy, setSortBy] = useState("dueDate");
  const [filterProject, setFilterProject] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [tasks, setTasks] = useState([]);
  const [statuses, setStatus] = useState([]);
  const [projects, setProjects] = useState([]);
  const [selectedTask, setSelectedTask] = useState(null);
  const [isTaskDetailsOpen, setIsTaskDetailsOpen] = useState(false);
  const { toast } = useToast();
  const [token, setToken] = useState(localStorage.getItem("token") || "");

  useEffect(() => {
    const fetchTasks = async () => {
      try {
        const response = await axios.get(`${apiUrl}/tasks/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });
        setTasks(response.data);

        const statusResponse = await axios.get(`${apiUrl}/statuses/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });
        setStatus(statusResponse.data);

        const projectResponse = await axios.get(`${apiUrl}/projects/all`, {
          headers: {
            "Authorization": `Bearer ${token}`
          }
        });
        setProjects(projectResponse.data);
      }
      catch(error) {
        console.error('Ошибка при получении задач:', error);
      }
    };

    fetchTasks();
  }, []);

  const getSortedTasks = () => {
    let filtered = [...tasks];
    
    if (searchTerm) {
      filtered = filtered.filter(task => 
        task.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.projectName.toLowerCase().includes(searchTerm.toLowerCase()) ||
        task.userAssignedName?.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterProject !== "all") {
      filtered = filtered.filter(task => task.projectName === filterProject);
    }

    return filtered.sort((a, b) => {
      switch (sortBy) {
        case "dueDate":
          return new Date(a.deadlineDate).getTime() - new Date(b.deadlineDate).getTime();
        case "assignee":
          return a.userAssignedName?.localeCompare(b.userAssignedName);
        case "project":
          return a.projectName.localeCompare(b.projectName);
        default:
          return 0;
      }
    });
  };

  const handleTaskClick = (task) => {
    setSelectedTask(task);
    setIsTaskDetailsOpen(true);
  };

  const handleDeleteTask = (taskId) => {
    setTasks(prevTasks => prevTasks.filter(task => task.id !== taskId));
  };

  const handleUpdateTask = (updatedTask) => {
    setTasks(prevTasks => 
      prevTasks.map(task => 
        task.id === updatedTask.id ? updatedTask : task
      )
    );
    setSelectedTask(updatedTask);
  };

  return (
    <div className="container mx-auto px-4 py-8 page-transition">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex md:flex-row justify-between items-start md:items-center mb-8 gap-4 pt-4">
          <div>
            <h1 className="text-4xl font-bold mb-4">Задачи</h1>
            <p className="text-muted-foreground">
              Управляйте и отслеживайте все задачи по проектам
            </p>
          </div>
          <CreateTaskDialog />
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Список задач</CardTitle>
            <CardDescription>
              Просмотр и управление всеми задачами по проектам
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex md:flex-row gap-4 mb-6">
              <Input
                placeholder="Поиск задач..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="md:w-1/3"
              />
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger className="md:w-1/4">
                  <SelectValue placeholder="Сортировать по" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dueDate">По сроку</SelectItem>
                  <SelectItem value="assignee">По исполнителю</SelectItem>
                  <SelectItem value="project">По проекту</SelectItem>
                </SelectContent>
              </Select>
              <Select value={filterProject} onValueChange={setFilterProject}>
                <SelectTrigger className="md:w-1/4">
                  <SelectValue placeholder="Фильтр по проекту" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Все проекты</SelectItem>
                  {
                    projects?.map((item, index) => (
                      <SelectItem key={index} value={item.name}>{item.name}</SelectItem>
                    ))
                  }
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-4">
              {getSortedTasks().map((task) => (
                <motion.div
                  key={task.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass p-4 cursor-pointer hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                  onClick={() => handleTaskClick(task)}
                >
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{task.name}</h3>
                      <p className="text-sm text-muted-foreground">{task.projectName}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        { task.userAssignedName == null ? "Не назначена" : task.userAssignedName }</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(task.deadlineDate).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="mt-2">
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium
                      ${task.statusId === 4 ? 'bg-blue-100 text-blue-800' : 
                        task.statusId === 3 ? 'bg-red-100 text-red-800' : 
                        task.statusId === 2 ? 'bg-orange-100 text-orange-800' : 
                        'bg-yellow-100 text-yellow-800'}`}>
                      {(statuses?.find(status => status.id === task.statusId))?.name}
                    </span>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Task details dialog */}
      <TaskDetailsDialog 
        task={selectedTask}
        isOpen={isTaskDetailsOpen}
        onOpenChange={setIsTaskDetailsOpen}
        onDelete={handleDeleteTask}
        onUpdate={handleUpdateTask}
      />
    </div>
  );
}
