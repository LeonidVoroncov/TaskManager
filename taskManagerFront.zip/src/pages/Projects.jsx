// import { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { FolderKanban, Users, Clock, BarChart } from "lucide-react";
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import config from '/config';
import { CreateProjectDialog } from "@/components/projects/CreateProjectDialog";

const apiUrl = config.apiUrl;
// Временные данные для демонстрации
const mockProjects = [
  {
    id: 1,
    title: "Веб-сайт компании",
    description: "Разработка нового корпоративного сайта",
    team: ["Александр К.", "Мария П.", "Дмитрий С."],
    progress: 75,
    deadline: "2024-04-15",
    status: "В работе"
  },
  {
    id: 2,
    title: "CRM Система",
    description: "Внедрение системы управления клиентами",
    team: ["Елена В.", "Павел М."],
    progress: 45,
    deadline: "2024-05-01",
    status: "В работе"
  },
  {
    id: 3,
    title: "Мобильное приложение",
    description: "Разработка мобильного приложения для iOS и Android",
    team: ["Анна С.", "Игорь П.", "Олег К."],
    progress: 30,
    deadline: "2024-06-30",
    status: "В работе"
  }
];

export default function Projects() {
  const [searchTerm, setSearchTerm] = useState("");
  const [projects, setProjects] = useState([]);
  const [token, setToken] = useState(localStorage.getItem("token") || "");

  const filteredProjects = projects.filter(project =>
    project.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    project.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  useEffect(() => {
    const fetchProjects = async () => {
      try {
        const response = await axios.get(`${apiUrl}/projects/all`, {
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`
          }
        });
        setProjects(response.data);
      } catch(error) {
        console.error('Ошибка при выполнении запроса:', error);
      }
    };

    fetchProjects();
  }, []);

  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex md:flex-row justify-between items-start md:items-center mb-8 gap-4 pt-4">
          <div>
            <h1 className="text-4xl font-bold mb-4">Проекты</h1>
            <p className="text-muted-foreground">
              Управление и мониторинг проектов компании
            </p>
          </div>
          <CreateProjectDialog />
        </div>

        <div className="grid grid-cols-1 gap-4 mb-8">
          <div className="glass p-4">
            <div className="flex items-center gap-2 text-lg font-semibold mb-2">
              <FolderKanban className="h-5 w-5" />
              <span>Всего проектов</span>
            </div>
            <p className="text-2xl font-bold">{filteredProjects.length}</p>
            <p className="text-muted-foreground">активных проектов</p>
          </div>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Список проектов</CardTitle>
            <CardDescription>
              Обзор всех текущих проектов и их статусов
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-6">
              <Input
                placeholder="Поиск проектов..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-md"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredProjects.map((project) => (
                <motion.div
                  key={project.id}
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="glass p-4"
                >
                  <h3 className="text-lg font-semibold mb-2">{project.name}</h3>
                  <p className="text-sm text-muted-foreground mb-4">{project.description}</p>

                  <div className="flex items-center gap-2 mb-3">
                    <Users className="h-4 w-4 text-muted-foreground" />
                    <div className="flex -space-x-2">
                      {project.users?.map((user, index) => (
                        <div
                          key={index}
                          className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-sm border-2 border-background"
                        >
                          {user.lastName.charAt(0)}
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
}
