import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import axios from 'axios';
import config from '/config';

const apiUrl = config.apiUrl;

export default function Auth() {
  const [isLogin, setIsLogin] = useState(true);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const formData = new FormData(e.currentTarget);

    const email = formData.get("email") as string;
    const password = formData.get("password") as string;

    if(isLogin){
      try {
        const response = await axios.post(`${apiUrl}/login`, {email, password});
        const userToken = response.data;

        localStorage.setItem("token", userToken);

        location.reload();
      }
      catch {
        toast({
          title: "Ошибка при входе",
          description: "Проверьте данные и попробуйте снова.",
          variant: "destructive",
        });

        return;
      }
    }
    else{
      try{
        const firstName = formData.get("firstName") as string;
        const lastName = formData.get("lastName") as string;
        const passwordConfirm = formData.get("repeatPassword") as string;
        const userName = firstName + lastName;
  
        const response = await axios.post(`${apiUrl}/register`, {email, password, firstName, lastName, userName, passwordConfirm});
          const userToken = response.data;
  
          localStorage.setItem("token", userToken);
  
          location.reload();
      } 
      catch {
        toast({
          title: "Ошибка при регистрации",
          description: "Проверьте данные и попробуйте снова.",
          variant: "destructive",
        });
  
        return;
      }
    }

    toast({
      title: isLogin ? "С возвращением!" : "Аккаунт успешно создан!",
    });

    setTimeout(() => navigate("/tasks"), 1500);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center px-4 page-transition">
      <div className="w-full max-w-md">
        <AnimatePresence mode="wait">
          <motion.div
            key={isLogin ? "login" : "register"}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.2 }}
            className="glass p-8"
          >
            <h2 className="text-2xl font-bold text-center mb-6">
              {isLogin ? "Welcome Back" : "Create Account"}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <>
                  <Input
                    type="text"
                    placeholder="First name"
                    required
                    className="w-full"
                    name="firstName"
                  />
                  <Input
                    type="text"
                    placeholder="Last name"
                    required
                    className="w-full"
                    name="lastName"
                  />
                  <div className="space-y-2">
                    <label className="block text-sm font-medium">
                      Profile Photo
                    </label>
                    <Input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="w-full"
                    />
                    {imagePreview && (
                      <div className="mt-2">
                        <img
                          src={imagePreview}
                          alt="Preview"
                          className="w-20 h-20 rounded-full object-cover mx-auto"
                        />
                      </div>
                    )}
                  </div>
                </>
              )}
              <Input
                type="email"
                placeholder="Email"
                required
                className="w-full"
                name="email"
              />
              <Input
                type="password"
                placeholder="Password"
                required
                className="w-full"
                name="password"
                minLength={6}
              />
              {!isLogin && (
                <Input
                  type="password"
                  placeholder="Repeat password"
                  required
                  className="w-full"
                  name="repeatPassword"
                />
              )}
              <Button type="submit" className="w-full">
                {isLogin ? "Login" : "Register"}
              </Button>
            </form>
            <div className="mt-4 text-center">
              <button
                onClick={() => setIsLogin(!isLogin)}
                className="text-sm underline hover:text-primary"
              >
                {isLogin
                  ? "Need an account? Register"
                  : "Already have an account? Login"}
              </button>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
