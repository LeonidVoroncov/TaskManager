
import { motion } from "framer-motion";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { BarChart, Calendar, CheckSquare, Users, FolderKanban, Clock } from "lucide-react";
import { BarChart as RechartsBarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

// Временные данные для графика
const chartData = [
  { name: 'Янв', задачи: 40, проекты: 24 },
  { name: 'Фев', задачи: 30, проекты: 13 },
  { name: 'Мар', задачи: 20, проекты: 28 },
  { name: 'Апр', задачи: 27, проекты: 39 },
  { name: 'Май', задачи: 18, проекты: 48 },
  { name: 'Июн', задачи: 23, проекты: 38 },
];

export default function Dashboard() {
  return (
    <div className="container mx-auto px-4 py-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Панель управления</h1>
          <p className="text-muted-foreground">
            Обзор проектов, задач и активности команды
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          <div className="glass p-4">
            <div className="flex items-center gap-2 text-lg font-semibold mb-2">
              <CheckSquare className="h-5 w-5" />
              <span>Задачи</span>
            </div>
            <p className="text-2xl font-bold">28</p>
            <p className="text-muted-foreground">активных задач</p>
          </div>
          <div className="glass p-4">
            <div className="flex items-center gap-2 text-lg font-semibold mb-2">
              <FolderKanban className="h-5 w-5" />
              <span>Проекты</span>
            </div>
            <p className="text-2xl font-bold">3</p>
            <p className="text-muted-foreground">текущих проекта</p>
          </div>
          <div className="glass p-4">
            <div className="flex items-center gap-2 text-lg font-semibold mb-2">
              <Users className="h-5 w-5" />
              <span>Команда</span>
            </div>
            <p className="text-2xl font-bold">12</p>
            <p className="text-muted-foreground">активных участников</p>
          </div>
          <div className="glass p-4">
            <div className="flex items-center gap-2 text-lg font-semibold mb-2">
              <Clock className="h-5 w-5" />
              <span>Сроки</span>
            </div>
            <p className="text-2xl font-bold">5</p>
            <p className="text-muted-foreground">задач на этой неделе</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-8">
          <Card>
            <CardHeader>
              <CardTitle>Статистика активности</CardTitle>
              <CardDescription>
                Количество задач и проектов по месяцам
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <RechartsBarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="задачи" fill="#3b82f6" />
                    <Bar dataKey="проекты" fill="#10b981" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Ближайшие дедлайны</CardTitle>
              <CardDescription>
                Задачи и проекты, требующие внимания
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="glass p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-semibold">Разработка дизайна</h4>
                      <p className="text-sm text-muted-foreground">Веб-сайт компании</p>
                    </div>
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                      2 дня
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">20 марта 2024</span>
                  </div>
                </div>

                <div className="glass p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-semibold">Тестирование API</h4>
                      <p className="text-sm text-muted-foreground">Мобильное приложение</p>
                    </div>
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-100 text-red-800">
                      Сегодня
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">18 марта 2024</span>
                  </div>
                </div>

                <div className="glass p-3">
                  <div className="flex justify-between items-start mb-2">
                    <div>
                      <h4 className="font-semibold">Настройка базы данных</h4>
                      <p className="text-sm text-muted-foreground">CRM Система</p>
                    </div>
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-orange-100 text-orange-800">
                      3 дня
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">21 марта 2024</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </motion.div>
    </div>
  );
}
