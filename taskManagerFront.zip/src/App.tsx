import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Navbar } from "./components/Navbar";
import { Button } from "@/components/ui/button";
import Auth from "./pages/Auth";
import Tasks from "./pages/Tasks";
import Projects from "./pages/Projects";
import Dashboard from "./pages/Dashboard";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import React, { useState, createContext, useContext } from "react";

const queryClient = new QueryClient();

export default function App(){
  return(
    <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <div className="min-h-screen w-full">
          <Navbar />
          <main className="pt-16">
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/auth" element={
                <RequireNoAuth>
                  <Auth />
                </RequireNoAuth>
              } />
              <Route path="/tasks" element={
                <RequireAuth>
                  <Tasks />
                </RequireAuth>
              } />
              <Route path="/projects" element={
                <RequireAuth>
                  <Projects  />
                </RequireAuth>
              } />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </main>
        </div>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
  );
};

function RequireAuth({ children }) {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  let location = useLocation();
  if (!token) {
    return <Navigate to="/auth" state={{ from: location }} replace />;
  }

  return children;
}

function RequireNoAuth({ children }) {
  const [token, setToken] = useState(localStorage.getItem("token") || "");
  let location = useLocation();
  if (token) {
    return <Navigate to="/" state={{ from: location }} replace />;
  }

  return children;
}